"""JSON-API для галереи и редактора. Доступ к датасету проверяет только auth.own_dataset."""

import os
import tempfile
from typing import Literal

from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
import threading

from starlette.background import BackgroundTask
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as DB

from app import auth, community, config, datasets, export, importer, previews
from app.db import Dataset, Image, get_db

router = APIRouter(prefix="/api/datasets/{dataset_id}")
# zip чужого большого датасета теперь может собрать любой пользователь — не больше двух сразу
_exports = threading.BoundedSemaphore(2)


class Classes(BaseModel):
    classes: list[str]


class Annotation(BaseModel):
    shapes: list[dict]


class SplitBody(BaseModel):
    split: Literal["train", "val", "test"]


def _find(db: DB, ds: Dataset, image_id: int) -> Image:
    try:
        return datasets.get_image(db, ds, image_id)
    except KeyError:
        raise HTTPException(404, "Картинка не найдена")


def _image(image_id: int, ds: Dataset = Depends(auth.own_dataset), db: DB = Depends(get_db)) -> Image:
    """Картинка своего датасета — для правки."""
    return _find(db, ds, image_id)


def _image_read(image_id: int, ds: Dataset = Depends(auth.readable_dataset), db: DB = Depends(get_db)) -> Image:
    """Картинка своего или опубликованного датасета — только для чтения."""
    return _find(db, ds, image_id)


def _brief(img: Image) -> dict:
    return {"id": img.id, "name": img.name, "split": img.split, "count": len(img.shapes)}


@router.get("")
def dataset(ds: Dataset = Depends(auth.readable_dataset), user=Depends(auth.api_user), db: DB = Depends(get_db)):
    images, _ = datasets.list_images(db, ds)
    return {"id": ds.id, "name": ds.name, "task": ds.task, "classes": ds.classes,
            "readonly": ds.owner_id != user.id, "images": [_brief(i) for i in images]}


@router.put("/classes")
def set_classes(body: Classes, ds: Dataset = Depends(auth.own_dataset), db: DB = Depends(get_db)):
    try:
        datasets.set_classes(db, ds, body.classes)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"classes": ds.classes}


# обычный def, не async: разбор картинок идёт в пуле потоков и не стопорит остальные запросы
@router.post("/images")
def upload(files: list[UploadFile], split: str = Form("train"),
           ds: Dataset = Depends(auth.own_dataset), db: DB = Depends(get_db)):
    added, errors = [], []
    for f in files:
        try:
            # на байт больше предела — чтобы отличить «ровно предел» от «больше»
            content = f.file.read(config.FILE_MAX_BYTES + 1)
            added.append(_brief(datasets.add_image(db, ds, f.filename or "image", content, split)))
        except ValueError as e:
            errors.append(f"{f.filename}: {e}")
    return {"added": added, "errors": errors}


@router.post("/import")
def import_zip(file: UploadFile, ds: Dataset = Depends(auth.own_dataset), db: DB = Depends(get_db)):
    try:
        return importer.import_zip(db, ds, file.file)
    except importer.ImportError_ as e:
        raise HTTPException(400, str(e))


@router.get("/images/{image_id}/file")
def image_file(img: Image = Depends(_image_read)):
    return FileResponse(datasets.image_file(img))


@router.get("/images/{image_id}/preview")
def preview(v: str = "", img: Image = Depends(_image_read)):
    # с ?v=<время правки> в адресе кэшируем надолго: после правки адрес другой;
    # без версии (обложки) — браузер каждый раз переспрашивает
    cache = "private, max-age=31536000" if v else "private, no-cache"
    return Response(previews.get(img), media_type="image/jpeg", headers={"Cache-Control": cache})


@router.get("/images/{image_id}/annotation")
def annotation(img: Image = Depends(_image_read)):
    return {"width": img.width, "height": img.height, "split": img.split, "shapes": img.shapes}


@router.put("/images/{image_id}/annotation")
def save_annotation(body: Annotation, img: Image = Depends(_image), ds: Dataset = Depends(auth.own_dataset),
                    db: DB = Depends(get_db)):
    try:
        datasets.save_shapes(db, img, datasets.clean_shapes(body.shapes, ds))
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@router.patch("/images/{image_id}")
def set_split(body: SplitBody, img: Image = Depends(_image), db: DB = Depends(get_db)):
    datasets.set_split(db, img, body.split)
    return _brief(img)


@router.delete("/images/{image_id}", status_code=204)
def delete_image(img: Image = Depends(_image), db: DB = Depends(get_db)):
    datasets.delete_image(db, img)


@router.get("/export")
def export_zip(format: Literal["acmenra", "ultralytics"] = "acmenra", ds: Dataset = Depends(auth.readable_dataset),
               user=Depends(auth.api_user), db: DB = Depends(get_db)):
    community.record_reuse(db, ds, user, "download")  # своё и закрытое не записывается
    # zip собирается во временный файл, а не в память: датасет бывает на гигабайты
    tmp_dir = config.data_dir() / "tmp"
    tmp_dir.mkdir(exist_ok=True)
    fd, path = tempfile.mkstemp(suffix=".zip", dir=tmp_dir)
    with _exports, os.fdopen(fd, "wb") as out:
        export.build_zip(db, ds, format, out)
    # имя датасета может быть кириллицей — в заголовке только ASCII, поэтому имя по id
    return FileResponse(path, media_type="application/zip", filename=f"dataset-{ds.id}-{ds.task}-{format}.zip",
                        background=BackgroundTask(os.unlink, path))
