"""Вход по email и паролю. Пароль — argon2, сессия — случайный токен в cookie, в базе его sha256.

Защита от CSRF держится на cookie SameSite=Lax: браузер не шлёт её с POST
с чужого сайта. Поэтому CORS с credentials в сервис добавлять нельзя.
"""

import hashlib
import secrets
import threading
import time
from collections import defaultdict, deque
from datetime import timedelta

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError
from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session as DB

from app import config
from app.db import Dataset, LoginSession, User, get_db, now

COOKIE = "acmenra_session"
_ph = PasswordHasher()
# хэш-заглушка: на несуществующий email тратим то же время, что на настоящий
_DUMMY = _ph.hash("not-a-real-password")


class LoginRequired(Exception):
    """Страница без входа — main.py превращает в переход на /login."""


class TooManyAttempts(Exception):
    """Перебор паролей или массовая регистрация с одного адреса."""


class AccountBlocked(Exception):
    """Пароль верный, но админ заблокировал аккаунт."""


# argon2 съедает 64 МБ памяти на один хэш — больше четырёх одновременно не считаем,
# иначе сорок параллельных попыток входа займут гигабайты
_crypto = threading.BoundedSemaphore(4)
# счётчики попыток живут в памяти процесса: сервис работает одним процессом
_attempts: dict[str, deque] = defaultdict(deque)
_attempts_lock = threading.Lock()


def _recent(key: str) -> int:
    edge = time.monotonic() - config.LIMIT_WINDOW_SEC
    with _attempts_lock:
        q = _attempts[key]
        while q and q[0] < edge:
            q.popleft()
        return len(q)


def _note(key: str) -> None:
    with _attempts_lock:
        _attempts[key].append(time.monotonic())


def _unnote(key: str) -> None:
    with _attempts_lock:
        if _attempts[key]:
            _attempts[key].pop()


def _hash_pw(password: str) -> str:
    with _crypto:
        return _ph.hash(password)


def normalize_email(email: str) -> str:
    return email.strip().lower()


def register(db: DB, email: str, password: str, ip: str = "") -> User:
    if _recent(f"reg:{ip}") >= config.REGISTER_PER_IP:
        raise TooManyAttempts()
    email = normalize_email(email)
    if "@" not in email or len(email) > 254:
        raise ValueError("Проверьте email")
    if len(password) < config.PASSWORD_MIN:
        raise ValueError(f"Пароль — не короче {config.PASSWORD_MIN} символов")
    if db.scalar(select(User).where(User.email == email)):
        raise ValueError("Такой email уже зарегистрирован")
    user = User(email=email, password_hash=_hash_pw(password), last_login_at=now())
    db.add(user)
    db.commit()
    _note(f"reg:{ip}")
    return user


def authenticate(db: DB, email: str, password: str, ip: str = "") -> User | None:
    email = normalize_email(email)
    if (_recent(f"email:{email}") >= config.LOGIN_FAILS_PER_EMAIL
            or _recent(f"ip:{ip}") >= config.LOGIN_FAILS_PER_IP):
        raise TooManyAttempts()
    user = db.scalar(select(User).where(User.email == email))
    # попытку записываем до проверки: иначе пачка параллельных запросов проскочила бы лимит
    _note(f"email:{email}")
    _note(f"ip:{ip}")
    try:
        with _crypto:
            _ph.verify(user.password_hash if user else _DUMMY, password)
    except VerificationError:
        return None
    _unnote(f"email:{email}")
    _unnote(f"ip:{ip}")
    # о блокировке говорим только после верного пароля: иначе по ответу узнавали бы,
    # какие email заблокированы
    if user.is_blocked:
        raise AccountBlocked()
    user.last_login_at = now()
    db.commit()
    return user


def check_password(user: User, password: str, ip: str = "") -> bool:
    """Подтверждение текущим паролем в настройках. Счётчик свой (по id пользователя),
    а не общий с входом по email: иначе посторонний, зная email, неудачными входами
    закрыл бы владельцу смену пароля как раз тогда, когда она нужнее всего."""
    key = f"confirm:{user.id}"
    if _recent(key) >= config.LOGIN_FAILS_PER_EMAIL or _recent(f"ip:{ip}") >= config.LOGIN_FAILS_PER_IP:
        raise TooManyAttempts()
    _note(key)
    _note(f"ip:{ip}")
    try:
        with _crypto:
            _ph.verify(user.password_hash, password)
    except VerificationError:
        return False
    _unnote(key)
    _unnote(f"ip:{ip}")
    return True


def set_password(db: DB, user: User, password: str) -> None:
    if len(password) < config.PASSWORD_MIN:
        raise ValueError(f"Пароль — не короче {config.PASSWORD_MIN} символов")
    user.password_hash = _hash_pw(password)
    db.commit()


def end_other_sessions(db: DB, user: User, keep_token: str | None) -> int:
    keep = _hash(keep_token) if keep_token else ""
    n = (db.query(LoginSession)
         .filter(LoginSession.user_id == user.id, LoginSession.token_hash != keep)
         .delete())
    db.commit()
    return n


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def start_session(db: DB, user: User) -> str:
    token = secrets.token_urlsafe(32)
    db.add(LoginSession(token_hash=_hash(token), user_id=user.id,
                        expires_at=now() + timedelta(days=config.SESSION_DAYS)))
    db.commit()
    return token


def end_session(db: DB, token: str | None) -> None:
    if token:
        s = db.get(LoginSession, _hash(token))
        if s:
            db.delete(s)
            db.commit()


def end_all_sessions(db: DB, user: User) -> None:
    db.query(LoginSession).filter(LoginSession.user_id == user.id).delete()
    db.commit()


def set_cookie(response, token: str) -> None:
    response.set_cookie(COOKIE, token, max_age=config.SESSION_DAYS * 86400, httponly=True,
                        samesite="lax", secure=config.COOKIE_SECURE, path="/")


def current_user(request: Request, db: DB = Depends(get_db)) -> User | None:
    token = request.cookies.get(COOKIE)
    if not token:
        return None
    s = db.get(LoginSession, _hash(token))
    if not s:
        return None
    if s.expires_at < now() or s.user.is_blocked:
        db.delete(s)
        db.commit()
        return None
    return s.user


def api_user(user: User | None = Depends(current_user)) -> User:
    if user is None:
        raise HTTPException(401, "Войдите заново")
    return user


def page_user(user: User | None = Depends(current_user)) -> User:
    if user is None:
        raise LoginRequired()
    return user


def _dataset(db: DB, dataset_id: str, user: User, write: bool) -> Dataset:
    """Единственная проверка доступа к датасету.

    Менять может только владелец. Читать — владелец, а опубликованный датасет — любой
    вошедший пользователь. Чужой закрытый и несуществующий отвечают одинаково 404,
    чтобы по ответу нельзя было узнать, есть ли такой датасет.
    """
    ds = db.get(Dataset, dataset_id)
    public = not write and ds is not None and ds.is_public and not db.get(User, ds.owner_id).is_blocked
    if ds is None or not (ds.owner_id == user.id or public):
        raise HTTPException(404, "Датасет не найден")
    return ds


def own_dataset(dataset_id: str, user: User = Depends(api_user), db: DB = Depends(get_db)) -> Dataset:
    return _dataset(db, dataset_id, user, write=True)


def own_dataset_page(dataset_id: str, user: User = Depends(page_user), db: DB = Depends(get_db)) -> Dataset:
    return _dataset(db, dataset_id, user, write=True)


def readable_dataset(dataset_id: str, user: User = Depends(api_user), db: DB = Depends(get_db)) -> Dataset:
    return _dataset(db, dataset_id, user, write=False)


def readable_dataset_page(dataset_id: str, user: User = Depends(page_user), db: DB = Depends(get_db)) -> Dataset:
    return _dataset(db, dataset_id, user, write=False)


def admin_page(user: User = Depends(page_user)) -> User:
    """Админка для остальных не существует: 404, а не 403."""
    if not user.is_admin:
        raise HTTPException(404, "Страница не найдена")
    return user
