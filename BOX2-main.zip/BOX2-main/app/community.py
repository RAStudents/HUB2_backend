"""Просмотры, лайки, переиспользования и рейтинг. Правила — docs/prd/leaderboard/prd.md.

Всё считается только по опубликованным датасетам и только действиями других людей:
свой лайк, своё скачивание и свой просмотр не записываются вовсе.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session as DB
from sqlalchemy.orm import aliased

from app.db import Dataset, Image, Like, Reuse, User, View, now

LIKE_POINTS = 5
REUSE_POINTS = 10
OBJECTS_PER_POINT = 10
VOLUME_CAP = 100  # баллов за объём с одного датасета
WEEK = timedelta(days=7)


def _counts(ds: Dataset, user: User) -> bool:
    """Действие идёт в счёт: датасет открыт и это не его автор."""
    return ds.is_public and ds.owner_id != user.id


def _insert_once(db: DB, row) -> bool:
    """Вставить, если такой строки ещё нет. Уникальный ключ защищает и от двойного клика."""
    db.add(row)
    try:
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        return False


def record_view(db: DB, ds: Dataset, user: User) -> None:
    if _counts(ds, user):
        _insert_once(db, View(dataset_id=ds.id, user_id=user.id, day=now().strftime("%Y-%m-%d")))


def record_reuse(db: DB, ds: Dataset, user: User, kind: str) -> None:
    if _counts(ds, user):
        _insert_once(db, Reuse(dataset_id=ds.id, user_id=user.id, kind=kind))


def toggle_like(db: DB, ds: Dataset, user: User) -> bool:
    """True — лайк поставлен, False — снят."""
    if not _counts(ds, user):
        raise ValueError("Свои и закрытые датасеты лайкать нельзя")
    existing = db.get(Like, (ds.id, user.id))
    if existing:
        db.delete(existing)
        db.commit()
        return False
    _insert_once(db, Like(dataset_id=ds.id, user_id=user.id))
    return True


def liked(db: DB, ds: Dataset, user: User) -> bool:
    return db.get(Like, (ds.id, user.id)) is not None


# --- счётчики на карточках ----------------------------------------------

def _active_actor():
    """Действия заблокированных пользователей не считаются."""
    return aliased(User)


def dataset_stats(db: DB, ids: list[str]) -> dict[str, dict]:
    """Просмотры, лайки, переиспользования (уникальные люди) для набора датасетов."""
    out = {i: {"views": 0, "likes": 0, "reuses": 0} for i in ids}
    if not ids:
        return out
    a = _active_actor()
    for key, model, col in (("views", View, func.count()), ("likes", Like, func.count()),
                            ("reuses", Reuse, func.count(func.distinct(Reuse.user_id)))):
        rows = db.execute(select(model.dataset_id, col).join(a, a.id == model.user_id)
                          .where(model.dataset_id.in_(ids), a.is_blocked.is_(False))
                          .group_by(model.dataset_id)).all()
        for ds_id, n in rows:
            out[ds_id][key] = n
    return out


def popularity(stats: dict) -> int:
    return stats["likes"] * LIKE_POINTS + stats["reuses"] * REUSE_POINTS


# --- рейтинг ------------------------------------------------------------

@dataclass
class Score:
    user: User
    likes: int = 0
    reuses: int = 0
    volume: int = 0
    datasets: int = 0
    place: int = 0

    @property
    def total(self) -> int:
        return self.likes * LIKE_POINTS + self.reuses * REUSE_POINTS + self.volume


def scores(db: DB, period: str = "all") -> list[Score]:
    """Все пользователи с баллами > 0, по убыванию; period — "week" или "all"."""
    since: datetime | None = now() - WEEK if period == "week" else None
    owner = aliased(User)
    actor = aliased(User)
    public = (Dataset.is_public.is_(True)) & (owner.is_blocked.is_(False))
    by_user: dict[int, Score] = {}

    def score_of(u: User) -> Score:
        return by_user.setdefault(u.id, Score(user=u))

    # лайки и переиспользования: на открытые датасеты, от других людей, не заблокированных
    for model, attr, col in ((Like, "likes", func.count()), (Reuse, "reuses", func.count(func.distinct(Reuse.user_id)))):
        stmt = (select(owner, Dataset.id, col)
                .join(Dataset, Dataset.owner_id == owner.id)
                .join(model, model.dataset_id == Dataset.id)
                .join(actor, actor.id == model.user_id)
                .where(public, actor.is_blocked.is_(False), model.user_id != Dataset.owner_id)
                .group_by(owner.id, Dataset.id))
        if since:
            stmt = stmt.where(model.created_at >= since)
        for u, _, n in db.execute(stmt).all():
            setattr(score_of(u), attr, getattr(score_of(u), attr) + n)

    # объём: свои (не скопированные) открытые датасеты, с потолком на каждый
    stmt = (select(owner, Dataset.id, func.coalesce(func.sum(func.json_array_length(Image.shapes)), 0))
            .join(Dataset, Dataset.owner_id == owner.id)
            .outerjoin(Image, Image.dataset_id == Dataset.id)
            .where(public, Dataset.forked_from.is_(None))
            .group_by(owner.id, Dataset.id))
    if since:
        stmt = stmt.where(Dataset.published_at >= since)
    for u, _, objects in db.execute(stmt).all():
        s = score_of(u)
        s.volume += min(VOLUME_CAP, int(objects) // OBJECTS_PER_POINT)

    # сколько открытых датасетов — для подписи в таблице
    for u, n in db.execute(select(owner, func.count(Dataset.id)).join(Dataset, Dataset.owner_id == owner.id)
                           .where(public).group_by(owner.id)).all():
        if u.id in by_user:
            by_user[u.id].datasets = n

    ranked = sorted((s for s in by_user.values() if s.total > 0),
                    key=lambda s: (-s.total, -s.reuses, -s.likes, s.user.id))
    for i, s in enumerate(ranked, 1):
        s.place = i
    return ranked


def score_for(db: DB, user: User, period: str = "all") -> Score:
    for s in scores(db, period):
        if s.user.id == user.id:
            return s
    return Score(user=user)
