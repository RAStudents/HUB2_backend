"""Настройки из переменных окружения — одно место на весь сервис."""

import os
from pathlib import Path


def data_dir() -> Path:
    d = Path(os.environ.get("ACMENRA_DATA_DIR", "data")).resolve()
    d.mkdir(parents=True, exist_ok=True)
    return d


def database_url() -> str:
    return os.environ.get("ACMENRA_DATABASE_URL", f"sqlite:///{data_dir() / 'acmenra.db'}")


# cookie только по HTTPS; локально без сертификата должно быть выключено
COOKIE_SECURE = os.environ.get("ACMENRA_COOKIE_SECURE", "0") == "1"
SESSION_DAYS = 30
PASSWORD_MIN = 8

# защита от zip-бомбы: считаем по заголовкам архива до распаковки
IMPORT_MAX_BYTES = int(os.environ.get("ACMENRA_IMPORT_MAX_BYTES", 2 * 1024**3))
IMPORT_MAX_FILES = int(os.environ.get("ACMENRA_IMPORT_MAX_FILES", 20000))
# один файл — и в zip, и при загрузке картинок; картинка больше 40 Мп отклоняется
# до распаковки пикселей (13000×13000 PNG весит ~500 КБ, а в памяти ~500 МБ)
FILE_MAX_BYTES = int(os.environ.get("ACMENRA_FILE_MAX_BYTES", 50 * 1024**2))
IMAGE_MAX_PIXELS = 40_000_000
MAX_CLASSES = 1000

# попытки входа: держим в памяти процесса — сервис работает одним процессом
LOGIN_FAILS_PER_EMAIL = 10
LOGIN_FAILS_PER_IP = 30
REGISTER_PER_IP = 10
LIMIT_WINDOW_SEC = 15 * 60

TASKS = ("detect", "segment", "obb")
SPLITS = ("train", "val", "test")
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp"}  # то, что читает acmenra-ds
PAGE_SIZE = 120
PREVIEW_SIZE = 320
