"""Датасеты и их картинки: база + файлы на диске.

data/datasets/<id>/images/<имя>        загруженные картинки
data/datasets/<id>/previews/<iid>.jpg  кэш превью с разметкой (app/previews.py)
"""

import io
import math
import os
import re
import secrets
import shutil
import threading
from pathlib import Path

from PIL import Image as PILImage
from PIL import ImageOps, UnidentifiedImageError
from sqlalchemy import case, func, select
from sqlalchemy.orm import Session as DB

from app import config
from app.db import Dataset, Image, User, now

_TRANSLIT = dict(zip(
    "абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
    "a b v g d e e zh z i y k l m n o p r s t u f h ts ch sh sch _ y _ e yu ya".split(),
))
_EXIF_ORIENTATION = 0x0112


def dataset_dir(ds_id: str) -> Path:
    return config.data_dir() / "datasets" / ds_id


def image_file(img: Image) -> Path:
    return dataset_dir(img.dataset_id) / "images" / img.name


def safe_image_name(name: str) -> str:
    """Имя файла только из латиницы, цифр, `_ - .`.

    Кириллица переводится в латиницу не для красоты: acmenra-ds читает картинки
    через cv2.imread, а он на Windows не открывает путь с не-ASCII символами —
    датасет с «кадр_1.jpg» их библиотека не загрузит.
    """
    name = name.replace("\\", "/").rsplit("/", 1)[-1]
    stem, ext = os.path.splitext(name)
    stem = "".join(_TRANSLIT.get(ch, _TRANSLIT.get(ch.lower(), ch).capitalize() if ch.isupper() else ch)
                   for ch in stem)
    stem = re.sub(r"[^A-Za-z0-9_\-.]+", "_", stem).strip("._") or "image"
    return stem[:120] + ext.lower()


def create_dataset(db: DB, owner: User, name: str, task: str, classes: list[str]) -> Dataset:
    if task not in config.TASKS:
        raise ValueError("Неизвестный вид разметки")
    classes = [c.strip() for c in classes if c.strip()]
    if len(set(classes)) != len(classes):
        raise ValueError("Классы повторяются")
    ds = Dataset(id=secrets.token_hex(4), owner_id=owner.id, name=name.strip()[:200] or "Без названия",
                 task=task, classes=classes)
    db.add(ds)
    db.commit()
    (dataset_dir(ds.id) / "images").mkdir(parents=True, exist_ok=True)
    return ds


# копия большого датасета — это гигабайты на диске; не больше двух копирований сразу
_copying = threading.BoundedSemaphore(2)


def copy_dataset(db: DB, src: Dataset, owner: User) -> Dataset:
    """Своя закрытая копия: картинки, разметка, классы и выборки как у исходного.
    Дальше копия живёт сама по себе — правки исходного её не трогают и наоборот."""
    with _copying:
        ds = create_dataset(db, owner, f"{src.name} (копия)"[:200], src.task, list(src.classes))
        ds.forked_from = src.id
        target = dataset_dir(ds.id) / "images"
        try:
            for img in db.scalars(select(Image).where(Image.dataset_id == src.id)).all():
                shutil.copy2(image_file(img), target / img.name)
                db.add(Image(dataset_id=ds.id, name=img.name, split=img.split, width=img.width,
                             height=img.height, shapes=[dict(s) for s in img.shapes]))
            db.commit()
        except Exception:
            # не оставляем полкопии: ни строк в базе, ни файлов на диске
            db.rollback()
            delete_dataset(db, ds)
            raise
    return ds


def delete_dataset(db: DB, ds: Dataset) -> None:
    db.delete(ds)
    db.commit()
    shutil.rmtree(dataset_dir(ds.id), ignore_errors=True)


def set_classes(db: DB, ds: Dataset, classes: list[str]) -> None:
    """Классы можно переименовать и дописать, но не удалить: номер класса — его позиция,
    удаление сдвинуло бы номера во всей уже сделанной разметке."""
    classes = [c.strip() for c in classes]
    if len(classes) < len(ds.classes):
        raise ValueError("Классы нельзя удалять — только переименовать или дописать")
    if not all(classes):
        raise ValueError("Имя класса не может быть пустым")
    if len(set(classes)) != len(classes):
        raise ValueError("Классы повторяются")
    if len(classes) > config.MAX_CLASSES:
        raise ValueError(f"Классов больше {config.MAX_CLASSES}")
    ds.classes = classes
    db.commit()


def _free_name(db: DB, ds: Dataset, name: str) -> str:
    stem, ext = os.path.splitext(name)
    taken = set(db.scalars(select(Image.name).where(Image.dataset_id == ds.id)))
    # stem — ключ разметки при выгрузке, поэтому уникальным должен быть он
    stems = {os.path.splitext(n)[0] for n in taken}
    base, n = stem, 1
    while stem in stems:
        n += 1
        stem = f"{base}_{n}"
    return stem + ext


def _decode(content: bytes) -> tuple[bytes, int, int]:
    """Проверяет картинку и возвращает (байты, ширина, высота).

    Фото с телефона хранят поворот в EXIF: браузер его применяет, Pillow — нет,
    и разметка разъехалась бы. Такие картинки поворачиваем сразу и пересохраняем;
    остальные оставляем байт в байт, чтобы не терять качество JPEG.
    """
    if len(content) > config.FILE_MAX_BYTES:
        raise ValueError(f"файл больше {config.FILE_MAX_BYTES // 1024**2} МБ")
    try:
        im = PILImage.open(io.BytesIO(content))  # читает только заголовок
        # размер — до распаковки пикселей: маленький PNG бывает огромным в памяти
        if im.width * im.height > config.IMAGE_MAX_PIXELS:
            raise ValueError(f"картинка больше {config.IMAGE_MAX_PIXELS // 1_000_000} Мп")
        im.load()
    except (UnidentifiedImageError, OSError, PILImage.DecompressionBombError) as e:
        raise ValueError("не картинка или файл повреждён") from e
    if im.getexif().get(_EXIF_ORIENTATION, 1) != 1:
        fmt = im.format
        im = ImageOps.exif_transpose(im)
        buf = io.BytesIO()
        im.save(buf, format=fmt or "JPEG", quality=95)
        content = buf.getvalue()
    return content, im.width, im.height


def add_image(db: DB, ds: Dataset, filename: str, content: bytes, split: str = "train",
              shapes: list | None = None, commit: bool = True) -> Image:
    name = safe_image_name(filename)
    if os.path.splitext(name)[1] not in config.IMAGE_EXTS:
        raise ValueError(f"поддерживаются {', '.join(sorted(config.IMAGE_EXTS))}")
    if split not in config.SPLITS:
        raise ValueError("неизвестная выборка")
    content, w, h = _decode(content)
    name = _free_name(db, ds, name)
    path = dataset_dir(ds.id) / "images" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    img = Image(dataset_id=ds.id, name=name, split=split, width=w, height=h, shapes=shapes or [])
    db.add(img)
    if commit:
        db.commit()
    else:
        db.flush()  # имя занято уже для следующей картинки в той же пачке
    return img


def get_image(db: DB, ds: Dataset, image_id: int) -> Image:
    img = db.get(Image, image_id)
    if img is None or img.dataset_id != ds.id:
        raise KeyError(image_id)
    return img


def list_images(db: DB, ds: Dataset, split: str | None = None, q: str = "",
                offset: int = 0, limit: int | None = None) -> tuple[list[Image], int]:
    stmt = select(Image).where(Image.dataset_id == ds.id)
    if split:
        stmt = stmt.where(Image.split == split)
    if q:
        stmt = stmt.where(Image.name.contains(q.strip()))
    total = db.scalar(stmt.with_only_columns(func.count(Image.id)))
    split_order = case({"train": 0, "val": 1, "test": 2}, value=Image.split, else_=9)
    stmt = stmt.order_by(split_order, Image.name).offset(offset)
    if limit:
        stmt = stmt.limit(limit)
    return list(db.scalars(stmt)), total


_FIELDS = {"box": ("x", "y", "w", "h"), "obb": ("cx", "cy", "w", "h", "angle")}


def _num(v) -> bool:
    # inf и nan не пускаем: JSON их не кодирует, и картинка перестала бы открываться
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def clean_shapes(shapes: list, ds: Dataset) -> list[dict]:
    """Фигуры от браузера пишутся в базу и потом рисуются в превью и выгрузке —
    поэтому пропускаем только известный вид с числами на местах."""
    out = []
    for s in shapes:
        kind = s.get("type")
        cls = s.get("cls")
        if kind not in ("box", "polygon", "obb") or not isinstance(cls, int) or not 0 <= cls < len(ds.classes):
            raise ValueError("Неверная фигура: вид или класс")
        if kind == "polygon":
            pts = s.get("points")
            if not isinstance(pts, list) or len(pts) < 3 or not all(
                    isinstance(p, list) and len(p) == 2 and all(_num(c) for c in p) for p in pts):
                raise ValueError("Неверная фигура: полигону нужно от 3 точек")
            out.append({"type": kind, "cls": cls, "points": [[float(x), float(y)] for x, y in pts]})
        else:
            vals = [s.get(k) for k in _FIELDS[kind]]
            if not all(_num(v) for v in vals):
                raise ValueError("Неверная фигура: координаты")
            out.append({"type": kind, "cls": cls, **{k: float(v) for k, v in zip(_FIELDS[kind], vals)}})
    return out


def save_shapes(db: DB, img: Image, shapes: list) -> None:
    img.shapes = shapes
    img.updated_at = now()
    db.commit()
    preview_path(img).unlink(missing_ok=True)


def set_split(db: DB, img: Image, split: str) -> None:
    if split not in config.SPLITS:
        raise ValueError("неизвестная выборка")
    img.split = split
    img.updated_at = now()
    db.commit()


def delete_image(db: DB, img: Image) -> None:
    image_file(img).unlink(missing_ok=True)
    preview_path(img).unlink(missing_ok=True)
    db.delete(img)
    db.commit()


def preview_path(img: Image) -> Path:
    return dataset_dir(img.dataset_id) / "previews" / f"{img.id}.jpg"
