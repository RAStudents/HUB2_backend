"""Модели и подключение к базе. SQLite по умолчанию, Postgres — сменой ACMENRA_DATABASE_URL."""

from datetime import datetime, timezone

from sqlalchemy import (JSON, Boolean, DateTime, ForeignKey, Integer, String, UniqueConstraint, create_engine, event,
                        inspect, text)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker

from app import config


def now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(254), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    display_name: Mapped[str | None] = mapped_column(String(60), nullable=True)
    avatar_v: Mapped[int | None] = mapped_column(Integer, nullable=True)  # время загрузки аватара; пусто — нет
    theme: Mapped[str] = mapped_column(String(8), default="light")


class LoginSession(Base):
    __tablename__ = "sessions"
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)  # sha256 токена, сам токен не храним
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    user: Mapped[User] = relationship()


class Dataset(Base):
    __tablename__ = "datasets"
    id: Mapped[str] = mapped_column(String(8), primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    task: Mapped[str] = mapped_column(String(16))
    classes: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    is_public: Mapped[bool] = mapped_column(Boolean, default=False)
    published_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    forked_from: Mapped[str | None] = mapped_column(String(8), nullable=True)  # id исходного, если это копия


class Image(Base):
    __tablename__ = "images"
    __table_args__ = (UniqueConstraint("dataset_id", "name"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255))
    split: Mapped[str] = mapped_column(String(8), default="train")
    width: Mapped[int] = mapped_column(Integer)
    height: Mapped[int] = mapped_column(Integer)
    # фигуры в пикселях исходной картинки; формат — в app/static/editor.js
    shapes: Mapped[list] = mapped_column(JSON, default=list)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now)


# --- сообщество: только для опубликованных датасетов (app/community.py) ---

class Like(Base):
    __tablename__ = "likes"
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id", ondelete="CASCADE"), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Reuse(Base):
    """Копия или скачивание чужим пользователем; повтор того же вида не записывается."""
    __tablename__ = "reuses"
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id", ondelete="CASCADE"), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True, index=True)
    kind: Mapped[str] = mapped_column(String(8), primary_key=True)  # copy | download
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class View(Base):
    """Один пользователь — один просмотр датасета в сутки."""
    __tablename__ = "views"
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id", ondelete="CASCADE"), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    day: Mapped[str] = mapped_column(String(10), primary_key=True)  # ГГГГ-ММ-ДД по UTC


_engine = None
_factory = None


def engine():
    global _engine, _factory
    if _engine is None:
        url = config.database_url()
        kw = {"connect_args": {"check_same_thread": False}} if url.startswith("sqlite") else {}
        _engine = create_engine(url, **kw)
        if url.startswith("sqlite"):
            @event.listens_for(_engine, "connect")
            def _fk(conn, _):
                conn.execute("PRAGMA foreign_keys=ON")
        Base.metadata.create_all(_engine)
        _add_missing_columns(_engine)
        _factory = sessionmaker(_engine, expire_on_commit=False)
    return _engine


# Столбцы, появившиеся после первой версии. create_all новые таблицы создаёт,
# а в существующие столбцы не добавляет — база с MVP иначе не открылась бы.
_ADDED = {
    "users": {"is_admin": "BOOLEAN NOT NULL DEFAULT FALSE", "is_blocked": "BOOLEAN NOT NULL DEFAULT FALSE",
              "last_login_at": "TIMESTAMP", "display_name": "VARCHAR(60)", "avatar_v": "INTEGER",
              "theme": "VARCHAR(8) NOT NULL DEFAULT 'light'"},
    "datasets": {"is_public": "BOOLEAN NOT NULL DEFAULT FALSE", "published_at": "TIMESTAMP",
                 "forked_from": "VARCHAR(8)"},
}


def _add_missing_columns(eng) -> None:
    insp = inspect(eng)
    with eng.begin() as conn:
        for table, cols in _ADDED.items():
            have = {c["name"] for c in insp.get_columns(table)}
            for name, ddl in cols.items():
                if name not in have:
                    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}"))


def get_db():
    """Одна сессия базы на запрос."""
    engine()
    with _factory() as s:
        yield s


def reset():
    """Для тестов: следующий engine() подключится заново по текущему env."""
    global _engine, _factory
    if _engine is not None:
        _engine.dispose()
    _engine = _factory = None
