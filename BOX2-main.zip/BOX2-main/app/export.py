"""Выгрузка датасета в zip с папками YOLO, выборки — как у файлов.

    data.yaml
    images/train/ labels/train/
    images/valid/ labels/valid/     ← выборка val
    images/test/  labels/test/

Папка проверочной выборки называется `valid`, а не `val`: acmenra-ds берёт имя
папки не из data.yaml, а из своей настройки `val_leaf`, у которой по умолчанию
"valid" (acmenra_ds/data/config.py). Ultralytics берёт путь из data.yaml.
"""

import math
import zipfile
from typing import BinaryIO

import yaml
from sqlalchemy.orm import Session as DB

from app import datasets
from app.db import Dataset, Image

FORMATS = ("acmenra", "ultralytics")
FOLDER = {"train": "train", "val": "valid", "test": "test"}


def _clamp(v: float) -> float:
    return min(1.0, max(0.0, v))


def _num(v: float) -> str:
    return f"{_clamp(v):.6f}"


def obb_corners(s: dict) -> list[tuple[float, float]]:
    """Углы повёрнутой рамки в пикселях: левый верхний, правый верхний, правый нижний, левый нижний."""
    c, si = math.cos(s["angle"]), math.sin(s["angle"])
    out = []
    for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        lx, ly = dx * s["w"] / 2, dy * s["h"] / 2
        out.append((s["cx"] + lx * c - ly * si, s["cy"] + lx * si + ly * c))
    return out


def shape_to_line(s: dict, task: str, w: int, h: int, fmt: str) -> str | None:
    """Одна фигура → строка YOLO. Фигура чужого вида разметки пропускается."""
    cls = int(s["cls"])
    if task == "detect" and s["type"] == "box":
        cx, cy = (s["x"] + s["w"] / 2) / w, (s["y"] + s["h"] / 2) / h
        return f"{cls} {_num(cx)} {_num(cy)} {_num(s['w'] / w)} {_num(s['h'] / h)}"
    if task == "segment" and s["type"] == "polygon" and len(s["points"]) >= 3:
        coords = " ".join(f"{_num(x / w)} {_num(y / h)}" for x, y in s["points"])
        return f"{cls} {coords}"
    if task == "obb" and s["type"] == "obb":
        if fmt == "ultralytics":
            # class x1 y1 x2 y2 x3 y3 x4 y4 — docs.ultralytics.com/datasets/obb
            coords = " ".join(f"{_num(x / w)} {_num(y / h)}" for x, y in obb_corners(s))
            return f"{cls} {coords}"
        # class cx cy w h угол_рад — acmenra_ds/label/parser.py::_parse_obb;
        # ширина делится на ширину кадра, высота на высоту, как в их Drawer
        angle = math.atan2(math.sin(s["angle"]), math.cos(s["angle"]))
        return (f"{cls} {_num(s['cx'] / w)} {_num(s['cy'] / h)} "
                f"{_num(s['w'] / w)} {_num(s['h'] / h)} {angle:.6f}")
    return None


def label_text(img: Image, task: str, fmt: str) -> str:
    """Пустой файл — картинка без объектов (фон); так её понимают и Ultralytics, и acmenra-ds."""
    lines = [shape_to_line(s, task, img.width, img.height, fmt) for s in img.shapes]
    return "".join(f"{line}\n" for line in lines if line)


def build_zip(db: DB, ds: Dataset, fmt: str, out: BinaryIO) -> None:
    if fmt not in FORMATS:
        raise ValueError(f"format должен быть одним из {FORMATS}")
    images, _ = datasets.list_images(db, ds)
    used = {img.split for img in images}

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for img in images:
            folder = FOLDER[img.split]
            stem = img.name.rsplit(".", 1)[0]
            z.write(datasets.image_file(img), f"images/{folder}/{img.name}")
            z.writestr(f"labels/{folder}/{stem}.txt", label_text(img, ds.task, fmt))
        if "train" not in used:
            # ключ train обязателен и для Ultralytics, и для acmenra-ds — оставляем пустую папку
            z.writestr("images/train/", "")
        # `path` не пишем: acmenra-ds тогда считает корнем папку с data.yaml,
        # а Ultralytics — тоже её, если yaml открыт по полному пути
        cfg = {"train": "images/train"}
        for split in ("val", "test"):
            if split in used:
                cfg[split] = f"images/{FOLDER[split]}"
        cfg.update({"task": ds.task, "nc": len(ds.classes), "names": dict(enumerate(ds.classes))})
        z.writestr("data.yaml", yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False))
