"""Загрузка готового датасета одним zip.

Понимает обе раскладки YOLO — `images/train/…` (Ultralytics) и `train/images/…`
(Roboflow), — выборки train / val (valid) / test, data.yaml с `names` списком
или словарём, а также архив без data.yaml. Пути из data.yaml не используются:
у Roboflow там `../train/images`, указывающий за пределы архива. Выборку и пару
«картинка — разметка» определяем по самим путям в архиве.
"""

import math
import zipfile
from pathlib import PurePosixPath
from typing import BinaryIO

import yaml
from sqlalchemy.orm import Session as DB

from app import config, datasets
from app.db import Dataset

SPLIT_WORDS = {"train": "train", "val": "val", "valid": "val", "validation": "val", "test": "test"}
MAX_REPORT = 50


class ImportError_(ValueError):
    """Архив не принят целиком (не zip, слишком большой)."""


def _members(zf: zipfile.ZipFile) -> dict[str, zipfile.ZipInfo]:
    out = {}
    for info in zf.infolist():
        if info.is_dir():
            continue
        path = info.filename.replace("\\", "/")
        parts = path.split("/")
        if parts[0] == "__MACOSX" or parts[-1].startswith("._"):
            continue
        out[path] = info
    return out


def _split_of(path: str) -> str:
    for part in PurePosixPath(path).parts[:-1]:
        if part.lower() in SPLIT_WORDS:
            return SPLIT_WORDS[part.lower()]
    return "train"


def _label_for(path: str, labels: dict[str, str], by_stem: dict[tuple[str, str], str]) -> str | None:
    p = PurePosixPath(path)
    parts = list(p.parts)
    # images/train/a.jpg → labels/train/a.txt;  train/images/a.jpg → train/labels/a.txt
    for i in range(len(parts) - 1, -1, -1):
        if parts[i].lower() == "images":
            cand = "/".join(parts[:i] + ["labels"] + parts[i + 1:-1] + [p.stem + ".txt"])
            if cand in labels:
                return cand
    same_dir = str(p.with_suffix(".txt"))
    if same_dir in labels:
        return same_dir
    return by_stem.get((_split_of(path), p.stem))


def _read_names(zf: zipfile.ZipFile, members: dict[str, zipfile.ZipInfo]) -> tuple[list[str] | None, str | None]:
    yamls = sorted((p for p in members if p.lower().endswith((".yaml", ".yml"))), key=lambda p: p.count("/"))
    for path in yamls:
        try:
            data = yaml.safe_load(zf.read(members[path]))
        except yaml.YAMLError:
            continue
        if not isinstance(data, dict) or "names" not in data:
            continue
        names = data["names"]
        try:
            if isinstance(names, dict):
                names = [names[k] for k in sorted(names, key=int)]
            names = [str(n).strip() for n in names]
        except (TypeError, ValueError) as e:
            raise ImportError_(f"{path}: names — список или словарь с номерами классов") from e
        if not all(names) or len(set(names)) != len(names) or len(names) > config.MAX_CLASSES:
            raise ImportError_(f"{path}: имена классов пустые, повторяются или их больше {config.MAX_CLASSES}")
        task = data.get("task") if data.get("task") in config.TASKS else None
        return names, task
    return None, None


def parse_line(parts: list[str], task: str, w: int, h: int) -> dict:
    """Строка YOLO → фигура в пикселях. Вид разметки решает датасет, а не длина строки:
    9 чисел в полигоне — четырёхугольник, в повёрнутой рамке — её четыре угла."""
    c = float(parts[0])
    if not c.is_integer() or not 0 <= c < config.MAX_CLASSES:
        raise ValueError(f"номер класса {parts[0]} — не целое от 0 до {config.MAX_CLASSES - 1}")
    cls = int(c)
    v = [float(x) for x in parts[1:]]
    if not all(math.isfinite(x) for x in v):
        raise ValueError("в координатах inf или nan")
    if task == "detect":
        if len(v) != 4:
            raise ValueError(f"рамке нужно 4 числа после класса, а тут {len(v)}")
        cx, cy, bw, bh = v
        return {"type": "box", "cls": cls, "x": (cx - bw / 2) * w, "y": (cy - bh / 2) * h, "w": bw * w, "h": bh * h}
    if task == "segment":
        if len(v) < 6 or len(v) % 2:
            raise ValueError(f"полигону нужно чётное число координат, от 6; тут {len(v)}")
        return {"type": "polygon", "cls": cls, "points": [[v[i] * w, v[i + 1] * h] for i in range(0, len(v), 2)]}
    if len(v) == 5:  # формат Acmenra: cx cy w h угол
        cx, cy, bw, bh, a = v
        return {"type": "obb", "cls": cls, "cx": cx * w, "cy": cy * h, "w": bw * w, "h": bh * h, "angle": a}
    if len(v) == 8:  # формат Ultralytics: четыре угла
        pts = [(v[i] * w, v[i + 1] * h) for i in range(0, 8, 2)]
        (x0, y0), (x1, y1), (x2, y2) = pts[0], pts[1], pts[2]
        return {"type": "obb", "cls": cls, "cx": sum(p[0] for p in pts) / 4, "cy": sum(p[1] for p in pts) / 4,
                "w": math.hypot(x1 - x0, y1 - y0), "h": math.hypot(x2 - x1, y2 - y1),
                "angle": math.atan2(y1 - y0, x1 - x0)}
    raise ValueError(f"повёрнутой рамке нужно 5 или 8 чисел после класса, а тут {len(v)}")


def import_zip(db: DB, ds: Dataset, fileobj: BinaryIO) -> dict:
    try:
        zf = zipfile.ZipFile(fileobj)
    except zipfile.BadZipFile as e:
        raise ImportError_("Это не zip-архив") from e
    with zf:
        members = _members(zf)
        if len(members) > config.IMPORT_MAX_FILES:
            raise ImportError_(f"В архиве больше {config.IMPORT_MAX_FILES} файлов")
        # размер по заголовкам — до распаковки, иначе zip-бомба успеет заполнить диск
        if sum(i.file_size for i in members.values()) > config.IMPORT_MAX_BYTES:
            raise ImportError_(f"Распакованный архив больше {config.IMPORT_MAX_BYTES // 1024**2} МБ")

        names, yaml_task = _read_names(zf, members)
        warnings, skipped = [], []
        if yaml_task and yaml_task != ds.task:
            warnings.append(f"в data.yaml вид разметки {yaml_task}, а у датасета {ds.task}: "
                            "строки чужого вида будут пропущены")
        # номер класса в архиве → номер в датасете; новые имена дописываются в конец
        mapping: dict[int, int] = {}
        if names is not None:
            classes = list(ds.classes)
            for i, n in enumerate(names):
                if n not in classes:
                    classes.append(n)
                mapping[i] = classes.index(n)
            try:
                datasets.set_classes(db, ds, classes)
            except ValueError as e:
                raise ImportError_(str(e)) from e

        labels = {p for p in members if p.lower().endswith(".txt")}
        by_stem = {(_split_of(p), PurePosixPath(p).stem): p for p in labels}
        images = sorted(p for p in members if PurePosixPath(p).suffix.lower() in config.IMAGE_EXTS)
        if not images:
            raise ImportError_("В архиве нет картинок (.jpg .jpeg .png .bmp)")

        added = 0
        for path in images:
            split = _split_of(path)
            if members[path].file_size > config.FILE_MAX_BYTES:
                skipped.append(f"{path}: файл больше {config.FILE_MAX_BYTES // 1024**2} МБ")
                continue
            try:
                img = datasets.add_image(db, ds, path, zf.read(members[path]), split, commit=False)
            except ValueError as e:
                skipped.append(f"{path}: {e}")
                continue
            added += 1
            label = _label_for(path, labels, by_stem)
            if not label:
                continue
            shapes = []
            if members[label].file_size > config.FILE_MAX_BYTES:
                skipped.append(f"{label}: файл разметки больше {config.FILE_MAX_BYTES // 1024**2} МБ")
                continue
            for n, raw in enumerate(zf.read(members[label]).decode("utf-8", "replace").splitlines(), 1):
                parts = raw.split()
                if not parts:
                    continue
                try:
                    shape = parse_line(parts, ds.task, img.width, img.height)
                except (ValueError, IndexError) as e:
                    skipped.append(f"{label}:{n}: {e}")
                    continue
                if names is not None:
                    if shape["cls"] not in mapping:
                        skipped.append(f"{label}:{n}: класс {shape['cls']} не описан в data.yaml")
                        continue
                    shape["cls"] = mapping[shape["cls"]]
                shapes.append(shape)
            img.shapes = shapes
            if added % 200 == 0:
                db.commit()

        if names is None:
            # без data.yaml классы называем по номерам
            top = max((s["cls"] for img in ds_images(db, ds) for s in img.shapes), default=-1)
            extra = [f"class_{i}" for i in range(len(ds.classes), top + 1)]
            if extra:
                datasets.set_classes(db, ds, ds.classes + extra)
            warnings.append("в архиве нет data.yaml — классы названы по номерам, переименовать их можно на странице датасета")
        db.commit()

    used = {i.split for i in ds_images(db, ds)}
    if "val" not in used:
        warnings.append("нет выборки val — Ultralytics без неё не обучает")
    return {"added": added, "skipped": len(skipped), "skipped_examples": skipped[:MAX_REPORT],
            "warnings": warnings, "classes": ds.classes}


def ds_images(db: DB, ds: Dataset):
    return datasets.list_images(db, ds)[0]
