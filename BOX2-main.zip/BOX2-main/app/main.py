"""Платформа разметки: страницы собирает сервер по шаблонам, редактор — canvas в static/editor.js.

Запуск: uv run uvicorn app.main:app --reload
"""

from pathlib import Path
from urllib.parse import quote

from fastapi import Depends, FastAPI, Form, HTTPException, Request, UploadFile
from fastapi.exception_handlers import http_exception_handler
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, select, true
from sqlalchemy.orm import Session as DB
from starlette.exceptions import HTTPException as StarletteHTTPException

from app import auth, community, config, datasets, profile
from app.api import router as api_router
from app.db import Dataset, Image, User, get_db, now
from app.previews import PALETTE

HERE = Path(__file__).parent
TASK_TITLE = {"detect": "Рамка", "segment": "Полигон", "obb": "Повёрнутая рамка"}

app = FastAPI(title="Acmenra — разметка датасетов", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=HERE / "static"), name="static")
app.include_router(api_router)
templates = Jinja2Templates(directory=HERE / "templates")
# версия статики в адресах: после обновления браузер не возьмёт старый css/js из кэша
ASSET_V = str(int(max(f.stat().st_mtime for f in (HERE / "static").iterdir())))
templates.env.globals.update(TASK_TITLE=TASK_TITLE, SPLITS=config.SPLITS, PALETTE=PALETTE, ASSET_V=ASSET_V,
                             public_name=profile.public_name, initials=profile.initials)


def render(request: Request, name: str, user: User | None, db: DB | None = None, status_code: int = 200, **ctx):
    """Страница после входа получает список своих датасетов для боковой панели."""
    if user is not None and db is not None:
        ctx["my_sets"] = db.execute(select(Dataset.id, Dataset.name, Dataset.is_public)
                                    .where(Dataset.owner_id == user.id)
                                    .order_by(Dataset.created_at.desc())).all()
    return templates.TemplateResponse(request, name, {"user": user, **ctx}, status_code=status_code)


@app.exception_handler(auth.LoginRequired)
def _to_login(request: Request, _):
    return RedirectResponse(f"/login?next={quote(request.url.path)}", status_code=303)


@app.exception_handler(StarletteHTTPException)
async def _html_errors(request: Request, exc: StarletteHTTPException):
    if request.url.path.startswith(("/api/", "/static/")):
        return await http_exception_handler(request, exc)
    return templates.TemplateResponse(request, "error.html", {"code": exc.status_code, "detail": exc.detail},
                                      status_code=exc.status_code)


def _safe_next(nxt: str | None) -> str:
    # только свой путь: иначе ссылка /login?next=https://чужой.сайт уводила бы после входа
    return nxt if nxt and nxt.startswith("/") and not nxt.startswith("//") else "/"


def _logged_in(user: User | None, nxt: str = "/"):
    return RedirectResponse(nxt, status_code=303) if user else None


def _ip(request: Request) -> str:
    return request.client.host if request.client else ""


# --- вход ----------------------------------------------------------------

@app.get("/login")
def login_page(request: Request, next: str = "/", user=Depends(auth.current_user)):
    return _logged_in(user) or render(request, "auth.html", None, mode="login", next=next)


def _too_many(request: Request, mode: str, email: str):
    return render(request, "auth.html", None, status_code=429, mode=mode, email=email,
                  error="Слишком много попыток. Подождите 15 минут.")


@app.post("/login")
def login(request: Request, email: str = Form(...), password: str = Form(...), next: str = Form("/"),
          db: DB = Depends(get_db)):
    try:
        user = auth.authenticate(db, email, password, _ip(request))
    except auth.TooManyAttempts:
        return _too_many(request, "login", email)
    except auth.AccountBlocked:
        return render(request, "auth.html", None, status_code=403, mode="login", next=next, email=email,
                      error="Аккаунт заблокирован администратором")
    if user is None:
        return render(request, "auth.html", None, status_code=400, mode="login", next=next, email=email,
                      error="Неверный email или пароль")
    resp = RedirectResponse(_safe_next(next), status_code=303)
    auth.set_cookie(resp, auth.start_session(db, user))
    return resp


@app.get("/register")
def register_page(request: Request, user=Depends(auth.current_user)):
    return _logged_in(user) or render(request, "auth.html", None, mode="register")


@app.post("/register")
def register(request: Request, email: str = Form(...), password: str = Form(...), db: DB = Depends(get_db)):
    try:
        user = auth.register(db, email, password, _ip(request))
    except auth.TooManyAttempts:
        return _too_many(request, "register", email)
    except ValueError as e:
        return render(request, "auth.html", None, status_code=400, mode="register", email=email, error=str(e))
    resp = RedirectResponse("/", status_code=303)
    auth.set_cookie(resp, auth.start_session(db, user))
    return resp


@app.post("/logout")
def logout(request: Request, db: DB = Depends(get_db)):
    auth.end_session(db, request.cookies.get(auth.COOKIE))
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie(auth.COOKIE, path="/")
    return resp


# --- датасеты ------------------------------------------------------------

def _with_counts(db: DB, where):
    """Датасеты с числом файлов, id первой картинки (обложка) и владельцем."""
    return db.execute(
        select(Dataset, func.count(Image.id), func.min(Image.id), User)
        .outerjoin(Image, Image.dataset_id == Dataset.id)
        .join(User, User.id == Dataset.owner_id)
        .where(where)
        .group_by(Dataset.id, User.id)
        .order_by(Dataset.created_at.desc())
    ).all()


@app.get("/")
def home(request: Request, user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    rows = _with_counts(db, Dataset.owner_id == user.id)
    return render(request, "home.html", user, db, rows=rows, tab="mine")


@app.get("/catalog")
def catalog(request: Request, q: str = "", sort: str = "new", user: User = Depends(auth.page_user),
            db: DB = Depends(get_db)):
    # датасеты заблокированных пользователей из каталога пропадают, пока их не разблокируют
    where = Dataset.is_public.is_(True) & User.is_blocked.is_(False)
    if q.strip():
        where = where & Dataset.name.contains(q.strip())
    rows = _with_counts(db, where)
    stats = community.dataset_stats(db, [ds.id for ds, *_ in rows])
    if sort == "popular":
        rows.sort(key=lambda r: community.popularity(stats[r[0].id]), reverse=True)
    return render(request, "catalog.html", user, db, rows=rows, q=q, tab="catalog", stats=stats,
                  sort="popular" if sort == "popular" else "new")


@app.post("/d/{dataset_id}/publish")
def publish(public: int = Form(...), ds: Dataset = Depends(auth.own_dataset_page), db: DB = Depends(get_db)):
    ds.is_public = bool(public)
    ds.published_at = now() if ds.is_public else None
    db.commit()
    return RedirectResponse(f"/d/{ds.id}", status_code=303)


@app.post("/datasets")
def create_dataset(request: Request, name: str = Form(...), task: str = Form(...), classes: str = Form(""),
                   user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    try:
        ds = datasets.create_dataset(db, user, name, task, classes.split(","))
    except ValueError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/d/{ds.id}", status_code=303)


@app.post("/d/{dataset_id}/copy")
def copy_dataset(ds: Dataset = Depends(auth.readable_dataset_page), user: User = Depends(auth.page_user),
                 db: DB = Depends(get_db)):
    """Копировать можно то, что можно читать: свой датасет или опубликованный.
    Пишет только в новый датасет, владелец которого — тот, кто копирует."""
    copy = datasets.copy_dataset(db, ds, user)
    community.record_reuse(db, ds, user, "copy")
    return RedirectResponse(f"/d/{copy.id}?copied=1", status_code=303)


@app.post("/d/{dataset_id}/like")
def like(ds: Dataset = Depends(auth.readable_dataset_page), user: User = Depends(auth.page_user),
         db: DB = Depends(get_db)):
    """Лайк чужого опубликованного датасета; повторное нажатие снимает лайк."""
    try:
        community.toggle_like(db, ds, user)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/d/{ds.id}", status_code=303)


@app.post("/d/{dataset_id}/delete")
def delete_dataset(ds: Dataset = Depends(auth.own_dataset_page), db: DB = Depends(get_db)):
    datasets.delete_dataset(db, ds)
    return RedirectResponse("/", status_code=303)


@app.get("/d/{dataset_id}")
def gallery(request: Request, split: str = "", q: str = "", page: int = 1, copied: int = 0,
            ds: Dataset = Depends(auth.readable_dataset_page), user: User = Depends(auth.page_user),
            db: DB = Depends(get_db)):
    split = split if split in config.SPLITS else ""
    page = max(1, page)
    images, total = datasets.list_images(db, ds, split or None, q, (page - 1) * config.PAGE_SIZE, config.PAGE_SIZE)
    counts = dict(db.execute(select(Image.split, func.count(Image.id))
                             .where(Image.dataset_id == ds.id).group_by(Image.split)).all())
    pages = max(1, -(-total // config.PAGE_SIZE))
    community.record_view(db, ds, user)
    return render(request, "gallery.html", user, db, stats=community.dataset_stats(db, [ds.id])[ds.id],
                  liked=community.liked(db, ds, user), ds=ds, images=images, total=total, counts=counts,
                  split=split, q=q, page=page, pages=pages, readonly=ds.owner_id != user.id,
                  owner=db.get(User, ds.owner_id), active_ds=ds.id, copied=bool(copied),
                  source=_source(db, ds, user))


def _source(db: DB, ds: Dataset, user: User):
    """Откуда скопирован датасет — ссылкой, если исходный ещё доступен этому пользователю."""
    if not ds.forked_from:
        return None
    src = db.get(Dataset, ds.forked_from)
    if src is None or not (src.owner_id == user.id or src.is_public):
        return None
    return src


@app.get("/d/{dataset_id}/i/{image_id}")
def editor(request: Request, image_id: int, ds: Dataset = Depends(auth.readable_dataset_page),
           user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    try:
        img = datasets.get_image(db, ds, image_id)
    except KeyError:
        raise HTTPException(404, "Картинка не найдена")
    return render(request, "editor.html", user, db, ds=ds, img=img, readonly=ds.owner_id != user.id,
                  active_ds=ds.id)


# --- профиль и настройки --------------------------------------------------

PROFILE_OK = {"name": "Имя сохранено", "avatar": "Аватар обновлён", "noavatar": "Аватар убран"}
SETTINGS_OK = {"theme": "Тема сохранена", "email": "Email изменён, остальные устройства вышли", "password": "Пароль изменён, остальные устройства вышли",
               "sessions": "Остальные устройства вышли из аккаунта"}


def _profile_page(request, user, db, error=None, ok="", status=200):
    n_sets, n_public = db.execute(select(func.count(Dataset.id), func.count(Dataset.id).filter(Dataset.is_public))
                                  .where(Dataset.owner_id == user.id)).one()
    return render(request, "profile.html", user, db, status_code=status, tab="profile", error=error,
                  ok=PROFILE_OK.get(ok), n_sets=n_sets, n_public=n_public, score=community.score_for(db, user))


@app.get("/profile")
def profile_page(request: Request, ok: str = "", user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    return _profile_page(request, user, db, ok=ok)


@app.post("/profile")
def profile_save(request: Request, display_name: str = Form(""), user: User = Depends(auth.page_user),
                 db: DB = Depends(get_db)):
    try:
        profile.set_display_name(db, user, display_name)
    except ValueError as e:
        return _profile_page(request, user, db, error=str(e), status=400)
    return RedirectResponse("/profile?ok=name", status_code=303)


@app.post("/profile/avatar")
def avatar_upload(request: Request, file: UploadFile, user: User = Depends(auth.page_user),
                  db: DB = Depends(get_db)):
    try:
        profile.save_avatar(db, user, file.file.read(profile.AVATAR_MAX_BYTES + 1))
    except ValueError as e:
        return _profile_page(request, user, db, error=str(e), status=400)
    return RedirectResponse("/profile?ok=avatar", status_code=303)


@app.post("/profile/avatar/delete")
def avatar_delete(user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    profile.remove_avatar(db, user)
    return RedirectResponse("/profile?ok=noavatar", status_code=303)


@app.get("/avatars/{user_id}.png")
def avatar(user_id: int, user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    """Аватары видны только вошедшим: платформа закрытая."""
    target = db.get(User, user_id)
    if target is None or target.avatar_v is None or not profile.avatar_path(user_id).exists():
        raise HTTPException(404, "Нет аватара")
    # в адресе стоит ?v=<время загрузки>, поэтому кэшировать можно надолго
    return FileResponse(profile.avatar_path(user_id), media_type="image/png",
                        headers={"Cache-Control": "private, max-age=31536000"})


def _settings_page(request, user, db, error=None, ok="", section="", status=200):
    return render(request, "settings.html", user, db, status_code=status, tab="settings", error=error,
                  error_section=section, ok=SETTINGS_OK.get(ok))


@app.get("/settings")
def settings_page(request: Request, ok: str = "", user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    return _settings_page(request, user, db, ok=ok)


@app.post("/settings/theme")
def settings_theme(request: Request, theme: str = Form(...), user: User = Depends(auth.page_user),
                   db: DB = Depends(get_db)):
    try:
        profile.set_theme(db, user, theme)
    except ValueError as e:
        return _settings_page(request, user, db, error=str(e), section="theme", status=400)
    return RedirectResponse("/settings?ok=theme", status_code=303)


def _confirm(request: Request, user: User, password: str, section: str, db: DB):
    """None — пароль верный; иначе готовая страница с ошибкой."""
    try:
        if auth.check_password(user, password, _ip(request)):
            return None
        return _settings_page(request, user, db, error="Текущий пароль неверный", section=section, status=400)
    except auth.TooManyAttempts:
        return _settings_page(request, user, db, error="Слишком много попыток. Подождите 15 минут.",
                              section=section, status=429)


@app.post("/settings/email")
def settings_email(request: Request, email: str = Form(...), password: str = Form(...),
                   user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    if (page := _confirm(request, user, password, "email", db)) is not None:
        return page
    try:
        profile.change_email(db, user, email)
    except ValueError as e:
        return _settings_page(request, user, db, error=str(e), section="email", status=400)
    # вход теперь по новому email — остальные устройства пусть войдут заново
    auth.end_other_sessions(db, user, request.cookies.get(auth.COOKIE))
    return RedirectResponse("/settings?ok=email", status_code=303)


@app.post("/settings/password")
def settings_password(request: Request, current: str = Form(...), new: str = Form(...),
                      user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    if (page := _confirm(request, user, current, "password", db)) is not None:
        return page
    try:
        auth.set_password(db, user, new)
    except ValueError as e:
        return _settings_page(request, user, db, error=str(e), section="password", status=400)
    # кто-то мог знать старый пароль: остальные устройства выходят, текущее остаётся
    auth.end_other_sessions(db, user, request.cookies.get(auth.COOKIE))
    return RedirectResponse("/settings?ok=password", status_code=303)


@app.post("/settings/sessions")
def settings_sessions(request: Request, user: User = Depends(auth.page_user), db: DB = Depends(get_db)):
    auth.end_other_sessions(db, user, request.cookies.get(auth.COOKIE))
    return RedirectResponse("/settings?ok=sessions", status_code=303)


@app.post("/settings/delete")
def settings_delete(request: Request, password: str = Form(...), user: User = Depends(auth.page_user),
                    db: DB = Depends(get_db)):
    if (page := _confirm(request, user, password, "delete", db)) is not None:
        return page
    profile.delete_user(db, user)
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie(auth.COOKIE, path="/")
    return resp


# --- рейтинг и публичный профиль ----------------------------------------

LEADERBOARD_TOP = 50


@app.get("/leaderboard")
def leaderboard(request: Request, period: str = "week", user: User = Depends(auth.page_user),
                db: DB = Depends(get_db)):
    period = "all" if period == "all" else "week"
    ranked = community.scores(db, period)
    mine = next((s for s in ranked if s.user.id == user.id), None)
    return render(request, "leaderboard.html", user, db, tab="leaderboard", period=period,
                  top=ranked[:LEADERBOARD_TOP], mine=mine, total_people=len(ranked),
                  rules={"like": community.LIKE_POINTS, "reuse": community.REUSE_POINTS,
                         "per": community.OBJECTS_PER_POINT, "cap": community.VOLUME_CAP})


@app.get("/u/{user_id}")
def public_profile(request: Request, user_id: int, user: User = Depends(auth.page_user),
                   db: DB = Depends(get_db)):
    """Публичная страница автора: только открытые датасеты, без email."""
    person = db.get(User, user_id)
    if person is None or person.is_blocked:
        raise HTTPException(404, "Пользователь не найден")
    rows = _with_counts(db, (Dataset.owner_id == person.id) & Dataset.is_public.is_(True))
    return render(request, "person.html", user, db, person=person, rows=rows,
                  stats=community.dataset_stats(db, [ds.id for ds, *_ in rows]),
                  score=community.score_for(db, person, "all"), week=community.score_for(db, person, "week"))


# --- админка -------------------------------------------------------------
# Админ назначается командой на сервере (scripts/admin.py), не через интерфейс.
# Закрытые датасеты админ не открывает: модерация — только снятие с публикации.

@app.get("/admin")
def admin(request: Request, user: User = Depends(auth.admin_page), db: DB = Depends(get_db)):
    users = db.execute(
        select(User, func.count(func.distinct(Dataset.id)), func.count(Image.id))
        .outerjoin(Dataset, Dataset.owner_id == User.id)
        .outerjoin(Image, Image.dataset_id == Dataset.id)
        .group_by(User.id)
        .order_by(User.created_at.desc())
    ).all()
    sets = _with_counts(db, true())
    return render(request, "admin.html", user, db, users=users, sets=sets, tab="admin",
                  n_blocked=sum(u.is_blocked for u, *_ in users), n_public=sum(ds.is_public for ds, *_ in sets))


def _target(db: DB, user_id: int, admin: User) -> User:
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(404, "Пользователь не найден")
    if target.id == admin.id:
        raise HTTPException(400, "Себя заблокировать или удалить нельзя")
    return target


@app.post("/admin/users/{user_id}/block")
def admin_block(user_id: int, blocked: int = Form(...), user: User = Depends(auth.admin_page),
                db: DB = Depends(get_db)):
    target = _target(db, user_id, user)
    target.is_blocked = bool(blocked)
    db.commit()
    if target.is_blocked:
        auth.end_all_sessions(db, target)  # выкидываем сразу, а не при следующем входе
    return RedirectResponse("/admin", status_code=303)


@app.post("/admin/users/{user_id}/delete")
def admin_delete(user_id: int, user: User = Depends(auth.admin_page), db: DB = Depends(get_db)):
    profile.delete_user(db, _target(db, user_id, user))
    return RedirectResponse("/admin", status_code=303)


@app.post("/admin/datasets/{dataset_id}/unpublish")
def admin_unpublish(dataset_id: str, user: User = Depends(auth.admin_page), db: DB = Depends(get_db)):
    ds = db.get(Dataset, dataset_id)
    if ds is None:
        raise HTTPException(404, "Датасет не найден")
    ds.is_public = False
    ds.published_at = None
    db.commit()
    return RedirectResponse("/admin", status_code=303)
