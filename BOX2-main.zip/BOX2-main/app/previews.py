"""Превью для галереи: уменьшенная картинка с нарисованной разметкой.

Рисуется при первом запросе и кладётся в кэш; сохранение разметки кэш сбрасывает
(datasets.save_shapes). Цвета классов — те же, что в редакторе.
"""

import uuid

from PIL import Image as PILImage
from PIL import ImageDraw

from app import config, datasets
from app.db import Image
from app.export import obb_corners

PALETTE = ["#ff5d5d", "#4f8cff", "#3ecf8e", "#ffb020", "#c06cff", "#20c5d6", "#ff7ac6", "#a3d636", "#ff8a3d", "#8c9eff"]


def _points(s: dict) -> list[tuple[float, float]]:
    if s["type"] == "box":
        x, y, w, h = s["x"], s["y"], s["w"], s["h"]
        return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
    if s["type"] == "obb":
        return obb_corners(s)
    return [tuple(p) for p in s["points"]]


def render(img: Image) -> bytes:
    with PILImage.open(datasets.image_file(img)) as src:
        im = src.convert("RGB")
    im.thumbnail((config.PREVIEW_SIZE, config.PREVIEW_SIZE))
    k = im.width / img.width
    layer = PILImage.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for s in img.shapes:
        col = PALETTE[int(s["cls"]) % len(PALETTE)]
        r, g, b = (int(col[i:i + 2], 16) for i in (1, 3, 5))
        pts = [(x * k, y * k) for x, y in _points(s)]
        if len(pts) >= 3:
            d.polygon(pts, fill=(r, g, b, 50), outline=(r, g, b, 255), width=2)
    out = PILImage.alpha_composite(im.convert("RGBA"), layer).convert("RGB")
    path = datasets.preview_path(img)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(f".{uuid.uuid4().hex}.tmp")  # своё имя у каждого потока
    out.save(tmp, "JPEG", quality=82)
    tmp.replace(path)
    return path.read_bytes()


def get(img: Image) -> bytes:
    path = datasets.preview_path(img)
    if path.exists():
        return path.read_bytes()
    return render(img)
