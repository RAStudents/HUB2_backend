"""Профиль и настройки пользователя: имя, аватар, email, пароль, тема, удаление аккаунта."""

import io
import threading
import time
import unicodedata
import uuid
from pathlib import Path

from PIL import Image as PILImage
from PIL import ImageOps
from sqlalchemy import select
from sqlalchemy.orm import Session as DB

from app import auth, config, datasets
from app.db import Dataset, User

AVATAR_SIZE = 256
AVATAR_MAX_BYTES = 5 * 1024**2
AVATAR_MAX_PIXELS = 12_000_000  # для аватара хватает с запасом; декодирование держит несколько копий
AVATAR_FORMATS = ["PNG", "JPEG", "WEBP"]
# не больше двух аватаров разбираются одновременно: каждый — сотни мегабайт на пике
_decode = threading.BoundedSemaphore(2)
NAME_MAX = 60
THEMES = ("light", "dark", "system")


def mask_email(email: str) -> str:
    """n***@gmail.com — так автор виден другим, если не задал имя."""
    local, _, domain = email.partition("@")
    return f"{local[:1]}***@{domain}"


def public_name(user: User) -> str:
    return user.display_name or mask_email(user.email)


def initials(user: User) -> str:
    src = (user.display_name or user.email.split("@")[0]).replace(".", " ").replace("_", " ").split()
    return "".join(w[0] for w in src[:2]).upper() or "?"


def avatar_path(user_id: int) -> Path:
    return config.data_dir() / "avatars" / f"{user_id}.png"


def set_display_name(db: DB, user: User, name: str) -> None:
    # невидимые символы и смена направления текста (U+202E и т.п.) позволяли бы
    # выдать себя за другого пользователя — убираем их до проверки длины
    name = "".join(ch for ch in name if unicodedata.category(ch) not in ("Cf", "Cc"))
    name = " ".join(name.split())
    if len(name) > NAME_MAX:
        raise ValueError(f"Имя — не длиннее {NAME_MAX} символов")
    user.display_name = name or None
    db.commit()


def save_avatar(db: DB, user: User, content: bytes) -> None:
    """Аватар пересохраняется квадратом 256×256 в PNG: так в файл не попадают EXIF,
    геометка и прочие метаданные исходного фото."""
    if len(content) > AVATAR_MAX_BYTES:
        raise ValueError(f"Файл больше {AVATAR_MAX_BYTES // 1024**2} МБ")
    with _decode:
        try:
            # только три формата: остальные декодеры Pillow до файла не допускаются
            im = PILImage.open(io.BytesIO(content), formats=AVATAR_FORMATS)
            if im.width * im.height > AVATAR_MAX_PIXELS:
                raise ValueError(f"Картинка больше {AVATAR_MAX_PIXELS // 1_000_000} Мп")
            im = ImageOps.exif_transpose(im)
            im.load()
            im = ImageOps.fit(im.convert("RGBA"), (AVATAR_SIZE, AVATAR_SIZE), PILImage.LANCZOS)
        except ValueError:
            raise
        except Exception as e:  # битые файлы роняют Pillow самыми разными исключениями
            raise ValueError("Это не картинка или файл повреждён") from e
    path = avatar_path(user.id)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(f".{uuid.uuid4().hex}.tmp")
    im.save(tmp, "PNG")
    tmp.replace(path)
    user.avatar_v = int(time.time())
    db.commit()


def remove_avatar(db: DB, user: User) -> None:
    avatar_path(user.id).unlink(missing_ok=True)
    user.avatar_v = None
    db.commit()


def set_theme(db: DB, user: User, theme: str) -> None:
    if theme not in THEMES:
        raise ValueError("Неизвестная тема")
    user.theme = theme
    db.commit()


def change_email(db: DB, user: User, new_email: str) -> None:
    email = auth.normalize_email(new_email)
    if "@" not in email or len(email) > 254:
        raise ValueError("Проверьте email")
    if email == user.email:
        return
    if db.scalar(select(User).where(User.email == email)):
        raise ValueError("Такой email уже зарегистрирован")
    user.email = email
    db.commit()


def delete_user(db: DB, user: User) -> None:
    """Аккаунт целиком: сеансы, датасеты с файлами, аватар.

    Сначала блокируем и выкидываем из сеансов — иначе, пока стираются датасеты,
    с другого устройства успели бы загрузить новые файлы."""
    user.is_blocked = True
    db.commit()
    auth.end_all_sessions(db, user)
    for ds in db.scalars(select(Dataset).where(Dataset.owner_id == user.id)).all():
        datasets.delete_dataset(db, ds)
    avatar_path(user.id).unlink(missing_ok=True)
    db.delete(user)
    db.commit()
