// Редактор разметки. Один файл без сборки и библиотек.
// Фигуры живут в пикселях исходной картинки; в формат YOLO их переводит сервер при выгрузке.
//   box     {type, cls, x, y, w, h}        — левый верхний угол и размер
//   polygon {type, cls, points: [[x,y]…]}
//   obb     {type, cls, cx, cy, w, h, angle} — угол в радианах, по часовой (ось Y вниз)

const PALETTE = ["#ff5d5d", "#4f8cff", "#3ecf8e", "#ffb020", "#c06cff", "#20c5d6", "#ff7ac6", "#a3d636", "#ff8a3d", "#8c9eff"];
const HINT = {
  select: "Клик по объекту — выбрать, тащить — сдвинуть, белые точки — изменить форму. Del — удалить. Клик по классу справа меняет класс выбранного.",
  detect: "Зажмите кнопку мыши и протяните рамку. Белые точки выбранной рамки тянутся.",
  segment: "Кликайте по контуру. Замкнуть — клик по первой точке, двойной клик или Enter. Backspace — убрать точку, Esc — отменить.",
  obb: "Клик — начало одной стороны, второй клик — её конец, третий — высота рамки. Верхняя точка поворачивает рамку.",
};
Object.assign(HINT, {
  rect: "Протяните прямоугольник — он станет полигоном из 4 точек. Shift — квадрат. Точки потом тянутся мышью.",
  ellipse: "Протяните эллипс — он станет полигоном из 24 точек. Shift — круг. Точки потом тянутся мышью.",
  free: "Ведите мышью с зажатой кнопкой по контуру объекта — точки ставятся сами, лишние убираются.",
  rect_obb: "Протяните рамку, затем поверните её за верхнюю точку или клавишами Q / E.",
});
const ELLIPSE_POINTS = 24;
// инструмент по клавише; работает, только если такой инструмент есть у вида разметки датасета
const TOOL_KEYS = { v: "select", "м": "select", r: "draw", "к": "draw", b: "rect", "и": "rect",
  o: "ellipse", "щ": "ellipse", f: "free", "а": "free" };
const HANDLE_R = 7;       // радиус захвата ручки, в пикселях экрана
const ROT_OFFSET = 26;    // ручка поворота над верхней стороной, в пикселях экрана

const $ = (s) => document.querySelector(s);
const ROOT = $(".editor");
const DS = ROOT.dataset.ds;
// чужой опубликованный датасет: смотреть можно, менять нельзя (сервер всё равно ответит 404)
const READONLY = ROOT.classList.contains("readonly");

async function api(url, opts = {}) {
  const r = await fetch(url, opts);
  if (r.status === 401) {
    const e = new Error("Сессия закончилась — войдите снова в соседней вкладке, правки не потеряются");
    e.auth = true;
    throw e;
  }
  if (!r.ok) {
    const body = await r.json().catch(() => ({}));
    throw new Error(typeof body.detail === "string" ? body.detail : `${r.status} ${r.statusText}`);
  }
  return r.status === 204 ? null : r.json();
}
const json = (method, body) => ({ method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

function toast(text, isError = false) {
  const t = $("#toast");
  t.textContent = text;
  t.className = "toast" + (isError ? " error" : "");
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.hidden = true), isError ? 8000 : 3500);
}

// ---------------------------------------------------------------- состояние

const S = {
  ds: null,            // {id, name, task, classes, images:[{id,name,split,count}]}
  index: -1,
  img: null,           // HTMLImageElement
  shapes: [],
  selected: -1,
  cls: 0,
  tool: "draw",
  draft: null,         // фигура в процессе рисования
  drag: null,          // перенос фигуры или ручки
  pan: null,
  view: { s: 1, ox: 0, oy: 0 },
  history: [],
  mouse: { x: 0, y: 0 },  // в координатах картинки
  spaceDown: false,
};

const canvas = $("#canvas");
const ctx = canvas.getContext("2d");
const stage = $("#stage");

async function init() {
  S.ds = await api(`/api/datasets/${DS}`);
  renderClasses();
  setTool(S.ds.classes.length ? "draw" : "select");
  const i = S.ds.images.findIndex((it) => it.id === Number(ROOT.dataset.image));
  await openImage(Math.max(0, i));
}

async function openImage(i) {
  await flushSave();
  const item = S.ds.images[i];
  if (!item) return;
  S.index = i;
  const base = `/api/datasets/${DS}/images/${item.id}`;
  const [img, ann] = await Promise.all([loadImage(`${base}/file`), api(`${base}/annotation`)]);
  if (S.index !== i) return;  // пока грузили, ушли на другую
  S.img = img;
  S.shapes = ann.shapes;
  S.selected = -1;
  S.draft = null;
  S.history = [];
  $("#split-select").value = ann.split;
  $("#image-pos").textContent = `${i + 1} / ${S.ds.images.length}`;
  $("#image-title").textContent = item.name;
  document.title = `${item.name} — ${S.ds.name}`;
  history.replaceState(null, "", `/d/${DS}/i/${item.id}`);
  fitView();
  renderImageList();
  renderShapes();
  draw();
}

const loadImage = (src) => new Promise((ok, fail) => {
  const im = new Image();
  im.onload = () => ok(im);
  im.onerror = () => fail(new Error("картинка не загрузилась"));
  im.src = src;
});

// ---------------------------------------------------------------- боковые панели

function renderImageList() {
  const ul = $("#image-list");
  ul.innerHTML = "";
  S.ds.images.forEach((it, i) => {
    const li = document.createElement("li");
    li.className = i === S.index ? "current" : "";
    li.innerHTML = `<span class="name"></span><span class="split split-${it.split}">${it.split}</span><span class="count ${it.count ? "" : "zero"}">${it.count}</span>`;
    li.querySelector(".name").textContent = it.name;
    li.addEventListener("click", () => openImage(i));
    ul.append(li);
  });
  ul.children[S.index]?.scrollIntoView({ block: "nearest" });
}

function renderClasses() {
  const ul = $("#class-list");
  ul.innerHTML = S.ds.classes.length ? "" : '<li class="muted">Добавьте хотя бы один класс</li>';
  S.ds.classes.forEach((name, i) => {
    const li = document.createElement("li");
    li.className = i === S.cls ? "current" : "";
    li.innerHTML = `<span class="dot" style="background:${color(i)}"></span><span class="name"></span>${i < 9 ? `<kbd>${i + 1}</kbd>` : ""}`;
    li.querySelector(".name").textContent = name;
    li.addEventListener("click", () => pickClass(i));
    ul.append(li);
  });
  document.querySelectorAll("[data-tool]:not([data-tool=select])").forEach((b) => (b.disabled = !S.ds.classes.length));
}

function renderShapes() {
  const ul = $("#shape-list");
  ul.innerHTML = "";
  $("#shape-count").textContent = S.shapes.length ? `(${S.shapes.length})` : "";
  S.shapes.forEach((s, i) => {
    const li = document.createElement("li");
    li.className = i === S.selected ? "current" : "";
    li.innerHTML = `<span class="dot" style="background:${color(s.cls)}"></span><span class="name"></span>${READONLY ? "" : '<button title="Удалить">×</button>'}`;
    li.querySelector(".name").textContent = S.ds.classes[s.cls] ?? `класс ${s.cls}`;
    li.addEventListener("click", () => { S.selected = i; setTool("select"); renderShapes(); draw(); });
    li.querySelector("button")?.addEventListener("click", (e) => { e.stopPropagation(); removeShape(i); });
    ul.append(li);
  });
  const item = S.ds?.images[S.index];
  if (item && item.count !== S.shapes.length) {
    item.count = S.shapes.length;
    const c = $("#image-list").children[S.index]?.querySelector(".count");
    if (c) { c.textContent = item.count; c.classList.toggle("zero", !item.count); }
  }
}

function pickClass(i) {
  if (READONLY || i >= S.ds.classes.length) return;
  S.cls = i;
  // в режиме рисования класс выбирают для следующей фигуры, а не перекрашивают только что нарисованную
  if (S.tool === "select" && S.selected >= 0 && S.shapes[S.selected].cls !== i) {
    pushHistory();
    S.shapes[S.selected].cls = i;
    changed();
  }
  renderClasses();
}

$("#add-class").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = e.target.elements.name;
  const name = input.value.trim();
  if (!name) return;
  try {
    const r = await api(`/api/datasets/${DS}/classes`, json("PUT", { classes: [...S.ds.classes, name] }));
    S.ds.classes = r.classes;
    S.cls = r.classes.length - 1;
    input.value = "";
    renderClasses();
    if (S.tool === "select" && S.selected < 0) setTool("draw");
  } catch (err) { toast(err.message, true); }
});

$("#split-select").addEventListener("change", async (e) => {
  const item = S.ds.images[S.index];
  try {
    await api(`/api/datasets/${DS}/images/${item.id}`, json("PATCH", { split: e.target.value }));
    item.split = e.target.value;
    renderImageList();
    toast(`Картинка перенесена в ${item.split}`);
  } catch (err) { toast(err.message, true); e.target.value = item.split; }
});

function setTool(t) {
  if (READONLY) t = "select";
  if (t !== "select" && !S.ds.classes.length) t = "select";
  S.tool = t;
  S.draft = null;
  document.querySelectorAll("[data-tool]").forEach((b) => b.classList.toggle("active", b.dataset.tool === t));
  $("#hint").textContent = READONLY ? "Только просмотр: листать ← →, масштаб колесом, сдвиг — пробел + мышь. Чтобы править — «Скопировать к себе» вверху справа."
    : t === "select" ? HINT.select : t === "draw" ? HINT[S.ds.task]
    : HINT[t === "rect" && S.ds.task === "obb" ? "rect_obb" : t];
  canvas.style.cursor = t !== "select" ? "crosshair" : "default";
  draw();
}
document.querySelectorAll("[data-tool]").forEach((b) => b.addEventListener("click", () => setTool(b.dataset.tool)));
$("#prev-btn").addEventListener("click", () => S.index > 0 && openImage(S.index - 1));
$("#next-btn").addEventListener("click", () => S.index < S.ds.images.length - 1 && openImage(S.index + 1));

// ---------------------------------------------------------------- сохранение

function changed() {
  if (READONLY) return;
  renderShapes();
  draw();
  $("#save-status").textContent = "Сохраняю…";
  clearTimeout(S.saveTimer);
  S.pendingSave = { id: S.ds.images[S.index].id, shapes: S.shapes };
  S.saveTimer = setTimeout(flushSave, 400);
}

async function flushSave() {
  clearTimeout(S.saveTimer);
  const p = S.pendingSave;
  if (!p) return;
  S.pendingSave = null;
  try {
    await api(`/api/datasets/${DS}/images/${p.id}/annotation`, json("PUT", { shapes: p.shapes }));
    $("#save-status").textContent = "Сохранено";
  } catch (err) {
    // не теряем правку: следующая попытка — при следующем изменении или переходе
    if (!S.pendingSave) S.pendingSave = p;
    $("#save-status").textContent = "Не сохранилось";
    toast(err.auth ? err.message : `Разметка не сохранилась: ${err.message}`, true);
  }
}
window.addEventListener("beforeunload", (e) => { if (S.pendingSave) { flushSave(); e.preventDefault(); } });

function pushHistory() {
  S.history.push(JSON.stringify(S.shapes));
  if (S.history.length > 100) S.history.shift();
}

function undo() {
  if (!S.history.length) return;
  S.shapes = JSON.parse(S.history.pop());
  S.selected = -1;
  changed();
}

function addShape(s) {
  pushHistory();
  S.shapes.push(s);
  S.selected = S.shapes.length - 1;
  changed();
}

function removeShape(i) {
  if (READONLY) return;
  pushHistory();
  S.shapes.splice(i, 1);
  S.selected = -1;
  changed();
}

// ---------------------------------------------------------------- вид: масштаб и сдвиг

function resizeCanvas() {
  const r = stage.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(r.width * dpr);
  canvas.height = Math.round(r.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function fitView() {
  resizeCanvas();
  if (!S.img) return;
  const r = stage.getBoundingClientRect();
  const s = Math.min((r.width - 40) / S.img.naturalWidth, (r.height - 40) / S.img.naturalHeight, 4);
  S.view = { s, ox: (r.width - S.img.naturalWidth * s) / 2, oy: (r.height - S.img.naturalHeight * s) / 2 };
}
new ResizeObserver(() => { fitView(); draw(); }).observe(stage);

const toImg = (e) => {
  const r = canvas.getBoundingClientRect();
  return { x: (e.clientX - r.left - S.view.ox) / S.view.s, y: (e.clientY - r.top - S.view.oy) / S.view.s };
};
const clampPt = (p) => ({
  x: Math.min(S.img.naturalWidth, Math.max(0, p.x)),
  y: Math.min(S.img.naturalHeight, Math.max(0, p.y)),
});

canvas.addEventListener("wheel", (e) => {
  if (!S.img) return;
  e.preventDefault();
  const r = canvas.getBoundingClientRect();
  const mx = e.clientX - r.left, my = e.clientY - r.top;
  const s = Math.min(40, Math.max(0.05, S.view.s * Math.exp(-e.deltaY * 0.0015)));
  S.view.ox = mx - (mx - S.view.ox) * (s / S.view.s);
  S.view.oy = my - (my - S.view.oy) * (s / S.view.s);
  S.view.s = s;
  draw();
}, { passive: false });

// ---------------------------------------------------------------- геометрия

function obbFromDraft(p1, p2, m) {
  const dx = p2.x - p1.x, dy = p2.y - p1.y;
  const len = Math.hypot(dx, dy);
  const nx = -dy / len, ny = dx / len;               // нормаль к первой стороне
  const d = (m.x - p1.x) * nx + (m.y - p1.y) * ny;   // высота со знаком
  return {
    type: "obb", cls: S.cls,
    cx: (p1.x + p2.x) / 2 + nx * d / 2,
    cy: (p1.y + p2.y) / 2 + ny * d / 2,
    w: len, h: Math.abs(d), angle: Math.atan2(dy, dx),
  };
}

const CORNERS = [[-1, -1], [1, -1], [1, 1], [-1, 1]];

function obbCorners(s) {
  const c = Math.cos(s.angle), si = Math.sin(s.angle);
  return CORNERS.map(([dx, dy]) => {
    const lx = dx * s.w / 2, ly = dy * s.h / 2;
    return [s.cx + lx * c - ly * si, s.cy + lx * si + ly * c];
  });
}

function rotHandle(s) {
  const d = s.h / 2 + ROT_OFFSET / S.view.s;
  return [s.cx + d * Math.sin(s.angle), s.cy - d * Math.cos(s.angle)];
}

function shapePoints(s) {
  if (s.type === "box") return [[s.x, s.y], [s.x + s.w, s.y], [s.x + s.w, s.y + s.h], [s.x, s.y + s.h]];
  if (s.type === "obb") return obbCorners(s);
  return s.points;
}

function insidePoly(p, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i], [xj, yj] = pts[j];
    if ((yi > p.y) !== (yj > p.y) && p.x < ((xj - xi) * (p.y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

function hitTest(p) {
  for (let i = S.shapes.length - 1; i >= 0; i--) if (insidePoly(p, shapePoints(S.shapes[i]))) return i;
  return -1;
}

// Ручки выбранной фигуры проверяются раньше тела — иначе ручку на краю не схватить.
function hitHandle(p) {
  const s = S.shapes[S.selected];
  if (!s) return null;
  const near = ([x, y]) => Math.hypot((x - p.x) * S.view.s, (y - p.y) * S.view.s) <= HANDLE_R;
  if (s.type === "obb" && near(rotHandle(s))) return { kind: "rotate" };
  const pts = shapePoints(s);
  for (let i = 0; i < pts.length; i++) if (near(pts[i])) return { kind: "vertex", i };
  return null;
}

function translate(s, orig, dx, dy) {
  if (s.type === "box") { s.x = orig.x + dx; s.y = orig.y + dy; }
  else if (s.type === "obb") { s.cx = orig.cx + dx; s.cy = orig.cy + dy; }
  else s.points = orig.points.map(([x, y]) => [x + dx, y + dy]);
}

function dragHandle(s, orig, h, m) {
  if (h.kind === "rotate") {
    s.angle = Math.atan2(m.y - orig.cy, m.x - orig.cx) + Math.PI / 2;
    return;
  }
  if (s.type === "polygon") {
    s.points[h.i] = [m.x, m.y];
  } else if (s.type === "box") {
    // противоположный угол стоит на месте
    const [ox, oy] = shapePoints(orig)[(h.i + 2) % 4];
    s.x = Math.min(ox, m.x); s.y = Math.min(oy, m.y);
    s.w = Math.abs(m.x - ox); s.h = Math.abs(m.y - oy);
  } else {
    // повёрнутая рамка: противоположный угол на месте, угол поворота не меняется
    const [ox, oy] = obbCorners(orig)[(h.i + 2) % 4];
    const dx = m.x - ox, dy = m.y - oy;
    const c = Math.cos(orig.angle), si = Math.sin(orig.angle);
    s.w = Math.abs(dx * c + dy * si);
    s.h = Math.abs(-dx * si + dy * c);
    s.cx = ox + dx / 2; s.cy = oy + dy / 2;
  }
}

// ---------------------------------------------------------------- мышь

canvas.addEventListener("mousedown", (e) => {
  if (!S.img) return;
  const p = toImg(e);
  if (e.button === 1 || S.spaceDown) {
    S.pan = { x: e.clientX, y: e.clientY, ox: S.view.ox, oy: S.view.oy };
    return;
  }
  if (e.button !== 0) return;
  if (READONLY) {
    S.selected = hitTest(p);
    renderShapes();
    draw();
    return;
  }

  if (!S.draft) {
    const h = hitHandle(p);
    if (h) {
      S.drag = { handle: h, start: p, orig: JSON.parse(JSON.stringify(S.shapes[S.selected])), moved: false };
      return;
    }
  }

  if (S.tool === "select") {
    const i = hitTest(p);
    S.selected = i;
    if (i >= 0) S.drag = { start: p, orig: JSON.parse(JSON.stringify(S.shapes[i])), moved: false };
    renderShapes();
    draw();
    return;
  }

  const q = clampPt(p);
  const task = S.ds.task;
  if (S.tool === "rect" || S.tool === "ellipse") {
    S.draft = { kind: "drag", form: S.tool, a: q, b: q, square: e.shiftKey };
  } else if (S.tool === "free") {
    S.draft = { kind: "free", points: [[q.x, q.y]] };
  } else if (task === "detect") {
    S.draft = { kind: "box", a: q, b: q };
  } else if (task === "segment") {
    if (!S.draft) S.draft = { kind: "polygon", points: [] };
    const pts = S.draft.points;
    const first = pts[0];
    if (pts.length >= 3 && Math.hypot((first[0] - q.x) * S.view.s, (first[1] - q.y) * S.view.s) < 8) finishPolygon();
    else pts.push([q.x, q.y]);
  } else if (task === "obb") {
    if (!S.draft) S.draft = { kind: "obb", p1: q };
    else if (!S.draft.p2) {
      if (Math.hypot(q.x - S.draft.p1.x, q.y - S.draft.p1.y) * S.view.s > 3) S.draft.p2 = q;
    } else {
      const s = obbFromDraft(S.draft.p1, S.draft.p2, q);
      S.draft = null;
      if (s.h * S.view.s > 2) addShape(s);
    }
  }
  draw();
});

window.addEventListener("mousemove", (e) => {
  if (!S.img) return;
  if (S.pan) {
    S.view.ox = S.pan.ox + e.clientX - S.pan.x;
    S.view.oy = S.pan.oy + e.clientY - S.pan.y;
    draw();
    return;
  }
  const p = toImg(e);
  S.mouse = p;
  if (S.drag) {
    const dx = p.x - S.drag.start.x, dy = p.y - S.drag.start.y;
    if (!S.drag.moved && Math.hypot(dx, dy) * S.view.s < 2) return;
    if (!S.drag.moved) { pushHistory(); S.drag.moved = true; }
    const s = S.shapes[S.selected];
    if (S.drag.handle) dragHandle(s, S.drag.orig, S.drag.handle, clampPt(p));
    else translate(s, S.drag.orig, dx, dy);
    draw();
    return;
  }
  if (S.draft?.kind === "box" || S.draft?.kind === "drag") {
    S.draft.b = clampPt(p);
    S.draft.square = e.shiftKey;
  }
  if (S.draft?.kind === "free") {
    // точку добавляем, только когда мышь ушла на 3 px экрана: иначе их тысячи
    const q = clampPt(p), last = S.draft.points.at(-1);
    if (Math.hypot((q.x - last[0]) * S.view.s, (q.y - last[1]) * S.view.s) >= 3) S.draft.points.push([q.x, q.y]);
  }
  if (S.draft) draw();
  else if (e.target === canvas && !S.spaceDown) {
    const h = hitHandle(p);
    canvas.style.cursor = h ? (h.kind === "rotate" ? "grab" : "move") : (S.tool !== "select" ? "crosshair" : "default");
  }
});

window.addEventListener("mouseup", () => {
  if (S.pan) { S.pan = null; return; }
  if (S.draft?.kind === "drag") {
    const d = S.draft;
    S.draft = null;
    const r = dragBox(d);
    if (r.w * S.view.s > 3 && r.h * S.view.s > 3) {
      addShape(S.ds.task === "obb" ? dragObb(d) : { type: "polygon", cls: S.cls, points: dragPoints(d) });
    } else draw();
    return;
  }
  if (S.draft?.kind === "free") {
    const pts = simplify(S.draft.points, 1.2 / S.view.s);
    S.draft = null;
    // контур обычно замыкают, возвращаясь к началу: последняя точка дублирует первую
    if (pts.length > 3 && Math.hypot((pts[0][0] - pts.at(-1)[0]) * S.view.s, (pts[0][1] - pts.at(-1)[1]) * S.view.s) < 8) pts.pop();
    if (pts.length >= 3) addShape({ type: "polygon", cls: S.cls, points: pts });
    else draw();
    return;
  }
  if (S.drag) {
    if (S.drag.moved) changed();
    S.drag = null;
    return;
  }
  if (S.draft?.kind === "box") {
    const { a, b } = S.draft;
    S.draft = null;
    const s = { type: "box", cls: S.cls, x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(a.x - b.x), h: Math.abs(a.y - b.y) };
    if (s.w * S.view.s > 3 && s.h * S.view.s > 3) addShape(s);
    else draw();
  }
});

canvas.addEventListener("dblclick", () => {
  if (S.draft?.kind !== "polygon") return;
  // двойной клик — это ещё и два одиночных: убираем лишнюю точку-дубль
  const pts = S.draft.points;
  while (pts.length > 1 && Math.hypot(pts.at(-1)[0] - pts.at(-2)[0], pts.at(-1)[1] - pts.at(-2)[1]) * S.view.s < 4) pts.pop();
  finishPolygon();
});

// --- фигуры, которые превращаются в полигон или повёрнутую рамку

function dragBox(d) {
  // прямоугольник по двум углам; с Shift — квадрат
  let w = d.b.x - d.a.x, h = d.b.y - d.a.y;
  if (d.square) {
    const m = Math.max(Math.abs(w), Math.abs(h));
    w = Math.sign(w || 1) * m;
    h = Math.sign(h || 1) * m;
  }
  return { x: Math.min(d.a.x, d.a.x + w), y: Math.min(d.a.y, d.a.y + h), w: Math.abs(w), h: Math.abs(h) };
}

function dragPoints(d) {
  const r = dragBox(d);
  let pts;
  if (d.form === "ellipse") {
    const cx = r.x + r.w / 2, cy = r.y + r.h / 2;
    pts = Array.from({ length: ELLIPSE_POINTS }, (_, i) => {
      const a = (i / ELLIPSE_POINTS) * 2 * Math.PI;
      return [cx + (r.w / 2) * Math.cos(a), cy + (r.h / 2) * Math.sin(a)];
    });
  } else {
    pts = [[r.x, r.y], [r.x + r.w, r.y], [r.x + r.w, r.y + r.h], [r.x, r.y + r.h]];
  }
  // квадрат с Shift мог выйти за край кадра
  return pts.map(([x, y]) => { const q = clampPt({ x, y }); return [q.x, q.y]; });
}

function dragObb(d) {
  const r = dragBox(d);
  return { type: "obb", cls: S.cls, cx: r.x + r.w / 2, cy: r.y + r.h / 2, w: r.w, h: r.h, angle: 0 };
}

// Рамер — Дуглас — Пекер: из сотен точек «от руки» оставляет те, что держат форму
function simplify(pts, eps) {
  if (pts.length < 3) return pts;
  const [ax, ay] = pts[0], [bx, by] = pts.at(-1);
  const len = Math.hypot(bx - ax, by - ay);
  let far = 0, idx = 0;
  for (let i = 1; i < pts.length - 1; i++) {
    const [x, y] = pts[i];
    const dist = len > 1e-9 ? Math.abs((by - ay) * x - (bx - ax) * y + bx * ay - by * ax) / len : Math.hypot(x - ax, y - ay);
    if (dist > far) { far = dist; idx = i; }
  }
  if (far <= eps) return [pts[0], pts.at(-1)];
  return [...simplify(pts.slice(0, idx + 1), eps).slice(0, -1), ...simplify(pts.slice(idx), eps)];
}

function finishPolygon() {
  const pts = S.draft?.points || [];
  S.draft = null;
  if (pts.length >= 3) addShape({ type: "polygon", cls: S.cls, points: pts });
  else draw();
}

// ---------------------------------------------------------------- клавиатура

window.addEventListener("keydown", (e) => {
  if (e.target.matches("input, select")) return;
  const k = e.key;
  if (READONLY && !["ArrowLeft", "ArrowRight", "Escape", " "].includes(k)) return;
  if (k === " ") { S.spaceDown = true; canvas.style.cursor = "grab"; e.preventDefault(); return; }
  if ((e.ctrlKey || e.metaKey) && (k === "z" || k === "я")) { e.preventDefault(); undo(); return; }
  if (k === "Escape") { S.draft = null; S.selected = -1; renderShapes(); draw(); return; }
  if (k === "Enter" && S.draft?.kind === "polygon") { finishPolygon(); return; }
  if (k === "Backspace" && S.draft?.kind === "polygon") { S.draft.points.pop(); if (!S.draft.points.length) S.draft = null; draw(); e.preventDefault(); return; }
  if ((k === "Delete" || k === "Backspace") && S.selected >= 0) { removeShape(S.selected); e.preventDefault(); return; }
  if (TOOL_KEYS[k] && !e.ctrlKey && !e.metaKey) {
    if (TOOL_KEYS[k] === "select" || document.querySelector(`[data-tool="${TOOL_KEYS[k]}"]`)) return setTool(TOOL_KEYS[k]);
  }
  if (k === "ArrowRight" || k === "d" || k === "в") return $("#next-btn").click();
  if (k === "ArrowLeft" || k === "a" || k === "ф") return $("#prev-btn").click();
  if (/^[1-9]$/.test(k)) return pickClass(Number(k) - 1);
  if ((k === "q" || k === "e" || k === "й" || k === "у") && S.shapes[S.selected]?.type === "obb") {
    const step = (e.shiftKey ? 1 : 5) * Math.PI / 180 * (k === "q" || k === "й" ? -1 : 1);
    pushHistory();
    S.shapes[S.selected].angle += step;
    changed();
  }
});
window.addEventListener("keyup", (e) => {
  if (e.key === " ") { S.spaceDown = false; canvas.style.cursor = S.tool !== "select" ? "crosshair" : "default"; }
});

// ---------------------------------------------------------------- отрисовка

const color = (i) => PALETTE[i % PALETTE.length];
const toScr = ([x, y]) => [S.view.ox + x * S.view.s, S.view.oy + y * S.view.s];

function draw() {
  const r = stage.getBoundingClientRect();
  ctx.clearRect(0, 0, r.width, r.height);
  if (!S.img) return;
  const { s, ox, oy } = S.view;
  ctx.imageSmoothingEnabled = s < 2;
  ctx.drawImage(S.img, ox, oy, S.img.naturalWidth * s, S.img.naturalHeight * s);

  S.shapes.forEach((sh, i) => drawShape(sh, shapePoints(sh), color(sh.cls), i === S.selected, S.ds.classes[sh.cls]));

  const d = S.draft;
  if (!d) return;
  const c = color(S.cls);
  if (d.kind === "box") {
    drawShape(null, [[d.a.x, d.a.y], [d.b.x, d.a.y], [d.b.x, d.b.y], [d.a.x, d.b.y]], c, false);
  } else if (d.kind === "polygon") {
    const m = clampPt(S.mouse);
    drawPath([...d.points, [m.x, m.y]], c, false);
    d.points.forEach((p, i) => handle(toScr(p), c, i === 0 && d.points.length >= 3));
  } else if (d.kind === "drag") {
    drawShape(null, S.ds.task === "obb" ? obbCorners(dragObb(d)) : dragPoints(d), c, false);
  } else if (d.kind === "free") {
    drawPath(d.points, c, false);
  } else if (d.kind === "obb") {
    const m = clampPt(S.mouse);
    if (!d.p2) drawPath([[d.p1.x, d.p1.y], [m.x, m.y]], c, false);
    else drawShape(null, obbCorners(obbFromDraft(d.p1, d.p2, m)), c, false);
    handle(toScr([d.p1.x, d.p1.y]), c);
  }
}

function drawPath(pts, c, closed) {
  ctx.beginPath();
  pts.forEach((p, i) => { const [x, y] = toScr(p); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
  if (closed) ctx.closePath();
  ctx.strokeStyle = c;
  ctx.lineWidth = 2;
  ctx.stroke();
}

function drawShape(sh, pts, c, selected, label) {
  drawPath(pts, c, true);
  ctx.globalAlpha = selected ? 0.3 : 0.15;
  ctx.fillStyle = c;
  ctx.fill();
  ctx.globalAlpha = 1;
  if (selected) {
    ctx.lineWidth = 3;
    ctx.stroke();
  }
  if (selected && !READONLY) {  // в режиме просмотра ручек нет: тянуть их всё равно нельзя
    pts.forEach((p) => handle(toScr(p), c));
    if (sh?.type === "obb") {
      const top = toScr([(pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2]);
      const rh = toScr(rotHandle(sh));
      ctx.beginPath(); ctx.moveTo(...top); ctx.lineTo(...rh); ctx.strokeStyle = c; ctx.lineWidth = 1.5; ctx.stroke();
      handle(rh, c, true);
    }
  }
  if (label) {
    const [x, y] = toScr(pts.reduce((a, b) => (b[1] < a[1] || (b[1] === a[1] && b[0] < a[0]) ? b : a)));
    ctx.font = "12px system-ui, sans-serif";
    const w = ctx.measureText(label).width + 8;
    ctx.fillStyle = c;
    ctx.fillRect(x, y - 18, w, 18);
    ctx.fillStyle = "#fff";
    ctx.fillText(label, x + 4, y - 5);
  }
}

function handle([x, y], c, big = false) {
  ctx.beginPath();
  ctx.arc(x, y, big ? 6 : 4.5, 0, Math.PI * 2);
  ctx.fillStyle = "#fff";
  ctx.fill();
  ctx.strokeStyle = c;
  ctx.lineWidth = 2;
  ctx.stroke();
}

// стартуем после объявления всего состояния
init().catch((e) => toast(e.message, true));
