// Галерея датасета: загрузка zip и картинок, правка классов. Плитки рисует сервер.

const DS = document.querySelector(".gallery").dataset.ds;
const $ = (s) => document.querySelector(s);

function toast(text, isError = false, ms = 4000) {
  const t = $("#toast");
  t.textContent = text;
  t.className = "toast" + (isError ? " error" : "");
  t.hidden = false;
  clearTimeout(toast.timer);
  if (ms) toast.timer = setTimeout(() => (t.hidden = true), ms);
}

async function send(url, opts) {
  const r = await fetch(url, opts);
  if (r.status === 401) { location.href = `/login?next=${encodeURIComponent(location.pathname)}`; throw new Error("Войдите заново"); }
  const body = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(typeof body.detail === "string" ? body.detail : `${r.status} ${r.statusText}`);
  return body;
}

async function importZip(file) {
  const fd = new FormData();
  fd.append("file", file);
  toast(`Загружаю ${file.name}…`, false, 0);
  try {
    const r = await send(`/api/datasets/${DS}/import`, { method: "POST", body: fd });
    const lines = [`Добавлено файлов: ${r.added}`];
    if (r.skipped) lines.push(`Пропущено: ${r.skipped} (${r.skipped_examples.slice(0, 3).join("; ")}${r.skipped > 3 ? "…" : ""})`);
    lines.push(...r.warnings);
    sessionStorage.setItem("acmenra-report", lines.join("\n"));
    location.reload();
  } catch (e) { toast(e.message, true); }
}

async function uploadImages(files) {
  const fd = new FormData();
  for (const f of files) fd.append("files", f);
  fd.append("split", $("#upload-split").value);
  toast(`Загружаю ${files.length}…`, false, 0);
  try {
    const r = await send(`/api/datasets/${DS}/images`, { method: "POST", body: fd });
    const lines = [`Добавлено: ${r.added.length}`, ...r.errors];
    sessionStorage.setItem("acmenra-report", lines.join("\n"));
    location.reload();
  } catch (e) { toast(e.message, true); }
}

function handleFiles(list) {
  const files = [...list];
  const zip = files.find((f) => f.name.toLowerCase().endsWith(".zip"));
  if (zip) importZip(zip);
  else if (files.length) uploadImages(files);
}

// у чужого опубликованного датасета панели загрузки и классов нет — отсюда «?.»
$("#zip-input")?.addEventListener("change", (e) => { handleFiles(e.target.files); e.target.value = ""; });
$("#files-input")?.addEventListener("change", (e) => { handleFiles(e.target.files); e.target.value = ""; });

const drop = $("#drop");
if ($("#zip-input")) {
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("dragover"); });
  drop.addEventListener("dragleave", (e) => { if (!drop.contains(e.relatedTarget)) drop.classList.remove("dragover"); });
  drop.addEventListener("drop", (e) => { e.preventDefault(); drop.classList.remove("dragover"); handleFiles(e.dataTransfer.files); });
}

$("#classes-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const classes = [...e.target.querySelectorAll("input[name=c]")].map((i) => i.value.trim());
  if (!classes.at(-1)) classes.pop();  // пустая строка «новый класс»
  try {
    await send(`/api/datasets/${DS}/classes`, {
      method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ classes }),
    });
    location.reload();
  } catch (err) { toast(err.message, true); }
});

$("#delete-form")?.addEventListener("submit", (e) => {
  // имя в confirm берём из data-атрибута, а не вставляем в onsubmit: кавычка в имени сломала бы JS
  if (!confirm(`Удалить датасет «${e.target.dataset.name}» со всеми файлами?`)) e.preventDefault();
});

const report = sessionStorage.getItem("acmenra-report");
if (report) {
  sessionStorage.removeItem("acmenra-report");
  toast(report, /Пропущено|нет /.test(report), 9000);
}
