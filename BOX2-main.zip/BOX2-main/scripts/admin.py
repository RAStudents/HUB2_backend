"""Назначить или снять админа. Через интерфейс этого сделать нельзя — только на сервере.

    uv run python scripts/admin.py grant user@example.com
    uv run python scripts/admin.py revoke user@example.com
    uv run python scripts/admin.py list

В Docker: docker exec <контейнер> uv run --no-sync python scripts/admin.py grant …
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select  # noqa: E402

from app import auth, db  # noqa: E402


def main(argv: list[str]) -> int:
    if not argv or argv[0] not in ("grant", "revoke", "list") or (argv[0] != "list" and len(argv) != 2):
        print(__doc__)
        return 2
    db.engine()
    with next(db.get_db()) as s:
        if argv[0] == "list":
            for u in s.scalars(select(db.User).where(db.User.is_admin.is_(True))):
                print(u.email)
            return 0
        email = auth.normalize_email(argv[1])
        user = s.scalar(select(db.User).where(db.User.email == email))
        if user is None:
            print(f"Нет пользователя {email}: сначала зарегистрируйтесь на сайте")
            return 1
        user.is_admin = argv[0] == "grant"
        s.commit()
        print(f"{email}: {'теперь админ' if user.is_admin else 'больше не админ'}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
