"""Искусственная активность для показа рейтинга: просмотры, лайки, копии и скачивания.

    uv run python scripts/seed_activity.py

Действуют только искусственные пользователи (example.com) и демо-аккаунт, по чужим
опубликованным датасетам, с датами за последние две недели — так у вкладок «за неделю»
и «за всё время» разные результаты. Настоящие аккаунты не трогаются.
Повторный запуск добавляет только то, чего ещё нет.
"""

import os
import random
import sys
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select  # noqa: E402

from app import db  # noqa: E402


def main():
    if os.environ.get("ACMENRA_COOKIE_SECURE") == "1":
        sys.exit("Похоже на боевой сервер (ACMENRA_COOKIE_SECURE=1): искусственную активность тут не заводим")
    rnd = random.Random(7)
    db.engine()
    added = {"просмотров": 0, "лайков": 0, "переиспользований": 0}
    with next(db.get_db()) as s:
        actors = [u for u in s.scalars(select(db.User).where(db.User.is_blocked.is_(False)))
                  if u.email.endswith("@example.com") or u.email == "demo@acmenra.local"]
        public = list(s.scalars(select(db.Dataset).where(db.Dataset.is_public.is_(True))))
        # у датасетов разная «популярность», иначе все места в рейтинге выйдут одинаковыми
        weight = {ds.id: rnd.uniform(0.15, 0.9) for ds in public}

        def ago():
            return db.now() - timedelta(days=rnd.uniform(0, 14), hours=rnd.uniform(0, 12))

        for ds in public:
            for u in actors:
                if u.id == ds.owner_id:
                    continue
                w = weight[ds.id]
                if rnd.random() < w:
                    for _ in range(rnd.randint(1, 3)):
                        day = ago().strftime("%Y-%m-%d")
                        if not s.get(db.View, (ds.id, u.id, day)):
                            s.add(db.View(dataset_id=ds.id, user_id=u.id, day=day))
                            added["просмотров"] += 1
                    if rnd.random() < w * 0.7 and not s.get(db.Like, (ds.id, u.id)):
                        s.add(db.Like(dataset_id=ds.id, user_id=u.id, created_at=ago()))
                        added["лайков"] += 1
                    if rnd.random() < w * 0.35:
                        kind = rnd.choice(["copy", "download", "download"])
                        if not s.get(db.Reuse, (ds.id, u.id, kind)):
                            s.add(db.Reuse(dataset_id=ds.id, user_id=u.id, kind=kind, created_at=ago()))
                            added["переиспользований"] += 1
        s.commit()
    print(", ".join(f"{k}: {v}" for k, v in added.items()))


if __name__ == "__main__":
    main()
