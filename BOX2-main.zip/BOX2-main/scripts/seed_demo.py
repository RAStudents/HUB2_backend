"""Демо-аккаунт с тремя датасетами — для показа и ручной проверки.

    uv run python scripts/seed_demo.py

Вход: demo@acmenra.local / demo-password (только для локального показа).
Картинки «склада» рисуются здесь же; часть уже размечена, выборки смешаны.
"""

import io
import math
import os
import random
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select  # noqa: E402

from app import auth, datasets, db  # noqa: E402

EMAIL, PASSWORD = "demo@acmenra.local", "demo-password"
W, H = 1280, 720


def scene(seed: int):
    """Пол, ящики (часть под углом) и шары. Возвращает jpeg и список объектов в пикселях."""
    rnd = random.Random(seed)
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):
        k = 0.75 + 0.35 * y / H
        d.line([(0, y), (W, y)], fill=(int(92 * k), int(80 * k), int(70 * k)))
    for x in range(0, W, 160):
        d.line([(x, 0), (x, H)], fill=(78, 68, 60), width=2)
    objects = []
    for _ in range(rnd.randint(2, 3)):
        cx, cy = rnd.randint(220, W - 220), rnd.randint(180, H - 220)
        w, h, a = rnd.randint(200, 290), rnd.randint(130, 180), math.radians(rnd.choice([0, 0, -28, 18, 35]))
        pts = []
        for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            lx, ly = dx * w / 2, dy * h / 2
            pts.append((cx + lx * math.cos(a) - ly * math.sin(a), cy + lx * math.sin(a) + ly * math.cos(a)))
        d.polygon([(x + 10, y + 12) for x, y in pts], fill=(52, 46, 42))
        d.polygon(pts, fill=(196, 128, 64), outline=(140, 88, 40), width=3)
        d.line([((pts[0][0] + pts[3][0]) / 2, (pts[0][1] + pts[3][1]) / 2),
                ((pts[1][0] + pts[2][0]) / 2, (pts[1][1] + pts[2][1]) / 2)], fill=(222, 206, 180), width=9)
        objects.append(("box", cx, cy, w, h, a, pts))
    for _ in range(rnd.randint(1, 2)):
        cx, cy, r = rnd.randint(120, W - 120), rnd.randint(H - 220, H - 90), rnd.randint(50, 75)
        col = rnd.choice([(214, 72, 58), (226, 196, 70)])
        d.ellipse([cx - r + 8, cy - r + 10, cx + r + 8, cy + r + 10], fill=(52, 46, 42))
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col)
        objects.append(("ball", cx, cy, r))
    im = im.filter(ImageFilter.GaussianBlur(0.6))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=90)
    return buf.getvalue(), objects


def shapes_for(task: str, objects) -> list[dict]:
    out = []
    for o in objects:
        if o[0] == "box":
            _, cx, cy, w, h, a, pts = o
            if task == "detect":
                xs, ys = [p[0] for p in pts], [p[1] for p in pts]
                out.append({"type": "box", "cls": 0, "x": min(xs), "y": min(ys), "w": max(xs) - min(xs), "h": max(ys) - min(ys)})
            elif task == "obb":
                out.append({"type": "obb", "cls": 0, "cx": cx, "cy": cy, "w": w, "h": h, "angle": a})
            else:
                out.append({"type": "polygon", "cls": 0, "points": [list(p) for p in pts]})
        else:
            _, cx, cy, r = o
            if task == "detect":
                out.append({"type": "box", "cls": 1, "x": cx - r, "y": cy - r, "w": 2 * r, "h": 2 * r})
            elif task == "segment":
                out.append({"type": "polygon", "cls": 1, "points": [[cx + r * math.cos(t * math.pi / 8), cy + r * math.sin(t * math.pi / 8)] for t in range(16)]})
    return out


def main():
    if os.environ.get("ACMENRA_COOKIE_SECURE") == "1":
        sys.exit("Похоже на боевой сервер (ACMENRA_COOKIE_SECURE=1): демо-аккаунт с известным паролем тут заводить нельзя")
    db.engine()
    with next(db.get_db()) as s:
        user = s.scalar(select(db.User).where(db.User.email == EMAIL)) or auth.register(s, EMAIL, PASSWORD)
        for task, title, n in [("detect", "Склад: ящики и шары", 14), ("segment", "Склад: контуры", 8),
                               ("obb", "Склад: повёрнутые ящики", 8)]:
            ds = datasets.create_dataset(s, user, title, task, ["ящик", "шар"])
            for i in range(n):
                content, objects = scene(i * 7 + len(task))
                split = "test" if i % 7 == 6 else "val" if i % 5 == 4 else "train"
                labeled = i % 4 != 3  # каждая четвёртая — без разметки, чтобы было что размечать
                datasets.add_image(s, ds, f"sklad_{i + 1:02d}.jpg", content, split,
                                   shapes_for(task, objects) if labeled else [])
            print(f"{title}: {n} картинок, id {ds.id}")
    print(f"Вход: {EMAIL} / {PASSWORD}")


if __name__ == "__main__":
    main()
