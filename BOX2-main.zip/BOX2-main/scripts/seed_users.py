"""Искусственные пользователи для показа админки и каталога.

    uv run python scripts/seed_users.py

Заводит 12 аккаунтов на домене example.com (не настоящие люди и не настоящие ящики):
имена, у части — аватары, даты регистрации и входа за последний месяц, у части —
датасеты со «складскими» картинками, часть датасетов опубликована, один аккаунт
заблокирован. Пароли случайные и нигде не сохраняются: войти под ними нельзя,
они нужны только чтобы платформа выглядела живой.
Повторный запуск пропускает тех, кто уже есть.
"""

import io
import os
import random
import secrets
import sys
from datetime import timedelta
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from sqlalchemy import select  # noqa: E402

from app import auth, datasets, db, profile  # noqa: E402
from seed_demo import scene, shapes_for  # noqa: E402

PEOPLE = [
    # имя, email, аватар, датасетов, опубликовать, заблокировать
    ("Анна Соколова", "anna.sokolova", True, 2, 1, False),
    ("Илья Морозов", "ilya.morozov", True, 1, 1, False),
    ("Мария Кузнецова", "maria.k", True, 1, 0, False),
    ("Дмитрий Волков", "d.volkov", False, 2, 1, False),
    ("Екатерина Лебедева", "kate.lebedeva", True, 0, 0, False),
    ("Артём Новиков", "artem.n", False, 1, 1, False),
    ("Полина Орлова", "polina.orlova", True, 1, 0, False),
    ("Сергей Павлов", "s.pavlov", True, 0, 0, True),
    ("", "lab.vision", False, 1, 1, False),
    ("Ольга Фёдорова", "olga.fedorova", True, 0, 0, False),
    ("Никита Смирнов", "nikita.smirnov", False, 1, 0, False),
    ("Виктория Ким", "vika.kim", True, 1, 1, False),
]
TITLES = {"detect": ["Склад: паллеты", "Каски на линии", "Ящики на ленте"],
          "segment": ["Контуры деталей", "Шары на складе"],
          "obb": ["Профили в ячейках", "Повёрнутые коробки"]}
AVATAR_COLORS = [((248, 80, 37), (255, 176, 120)), ((47, 111, 224), (140, 190, 255)), ((31, 138, 91), (150, 225, 180)),
                 ((192, 108, 255), (240, 190, 255)), ((25, 25, 25), (110, 110, 110)), ((185, 122, 0), (255, 214, 120))]


def avatar_png(name: str, rnd: random.Random) -> bytes:
    """Градиент и инициалы — вместо фотографий, которых у вымышленных людей нет."""
    a, b = rnd.choice(AVATAR_COLORS)
    im = Image.new("RGB", (256, 256))
    d = ImageDraw.Draw(im)
    for y in range(256):
        t = y / 255
        d.line([(0, y), (256, y)], fill=tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)))
    letters = "".join(w[0] for w in name.split()[:2]).upper()
    try:
        font = ImageFont.truetype("segoeuib.ttf", 104)
    except OSError:
        font = ImageFont.load_default(104)
    d.text((128, 132), letters, font=font, fill="white", anchor="mm")
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue()


def main():
    if os.environ.get("ACMENRA_COOKIE_SECURE") == "1":
        sys.exit("Похоже на боевой сервер (ACMENRA_COOKIE_SECURE=1): искусственных пользователей тут не заводим")
    rnd = random.Random(42)
    db.engine()
    added = 0
    with next(db.get_db()) as s:
        for i, (name, login, has_avatar, n_sets, n_pub, blocked) in enumerate(PEOPLE):
            email = f"{login}@example.com"
            if s.scalar(select(db.User).where(db.User.email == email)):
                continue
            user = db.User(email=email, password_hash=auth._hash_pw(secrets.token_urlsafe(24)),
                           display_name=name or None)
            reg = db.now() - timedelta(days=rnd.randint(2, 32), hours=rnd.randint(0, 23))
            user.created_at = reg
            user.last_login_at = reg + timedelta(days=rnd.randint(0, (db.now() - reg).days), hours=rnd.randint(0, 12))
            s.add(user)
            s.commit()
            if has_avatar:
                profile.save_avatar(s, user, avatar_png(name, rnd))
            for k in range(n_sets):
                task = rnd.choice(list(TITLES))
                ds = datasets.create_dataset(s, user, rnd.choice(TITLES[task]), task, ["ящик", "шар"])
                ds.created_at = reg + timedelta(hours=rnd.randint(1, 48))
                for j in range(rnd.randint(3, 6)):
                    content, objects = scene(i * 31 + k * 7 + j)
                    split = "val" if j == 2 else "test" if j == 5 else "train"
                    datasets.add_image(s, ds, f"frame_{j + 1:02d}.jpg", content, split,
                                       shapes_for(task, objects) if j % 3 != 1 else [])
                if k < n_pub:
                    ds.is_public = True
                    ds.published_at = ds.created_at + timedelta(hours=2)
                s.commit()
            if blocked:
                user.is_blocked = True
                s.commit()
            added += 1
            print(f"+ {name or email}: датасетов {n_sets}, опубликовано {n_pub}{', заблокирован' if blocked else ''}")
    print(f"Добавлено пользователей: {added}")


if __name__ == "__main__":
    main()
