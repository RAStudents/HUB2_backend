"""Сценарий MVP через HTTP: вход, изоляция пользователей, zip туда и обратно.

Выгрузка проверяется не строкой-эталоном, а библиотекой Acmenra (acmenra-ds):
главное обещание платформы — их код открывает датасет без правок.
"""

import io
import math
import zipfile
from enum import Enum

import pytest
import yaml
from fastapi.testclient import TestClient
from PIL import Image as PILImage

W, H = 640, 480


@pytest.fixture
def make_client(tmp_path, monkeypatch):
    monkeypatch.setenv("ACMENRA_DATA_DIR", str(tmp_path / "data"))
    from app import auth, db
    db.reset()
    auth._attempts.clear()
    from app.main import app

    def make(email: str | None = "a@example.com") -> TestClient:
        c = TestClient(app)
        if email:
            r = c.post("/register", data={"email": email, "password": "correct-horse"}, follow_redirects=False)
            assert r.status_code == 303
        return c

    yield make
    db.reset()


def jpg(color=(120, 120, 120)) -> bytes:
    buf = io.BytesIO()
    PILImage.new("RGB", (W, H), color).save(buf, "JPEG")
    return buf.getvalue()


def zip_bytes(files: dict[str, bytes | str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()


def create(c: TestClient, task: str, classes: str = "") -> str:
    r = c.post("/datasets", data={"name": "тест", "task": task, "classes": classes}, follow_redirects=False)
    assert r.status_code == 303
    return r.headers["location"].rsplit("/", 1)[-1]


def test_register_login_logout(make_client):
    c = make_client()
    assert c.get("/", follow_redirects=False).status_code == 200

    c.post("/logout")
    assert c.get("/", follow_redirects=False).headers["location"].startswith("/login")
    assert c.get("/api/datasets/abcd1234").status_code == 401

    bad = c.post("/login", data={"email": "a@example.com", "password": "wrong-password"}, follow_redirects=False)
    nobody = c.post("/login", data={"email": "no@example.com", "password": "wrong-password"}, follow_redirects=False)
    assert bad.status_code == nobody.status_code == 400
    assert "Неверный email или пароль" in bad.text and "Неверный email или пароль" in nobody.text

    ok = c.post("/login", data={"email": " A@Example.com ", "password": "correct-horse", "next": "//evil.example"},
                follow_redirects=False)
    assert ok.status_code == 303 and ok.headers["location"] == "/"

    again = make_client(None).post("/register", data={"email": "A@EXAMPLE.COM", "password": "another-pass"})
    assert again.status_code == 400 and "уже зарегистрирован" in again.text


def test_other_user_cannot_reach_dataset(make_client):
    alice, bob = make_client("alice@example.com"), make_client("bob@example.com")
    ds = create(alice, "detect", "a")
    img = alice.post(f"/api/datasets/{ds}/images", files=[("files", ("x.jpg", jpg(), "image/jpeg"))]).json()["added"][0]
    base, iid = f"/api/datasets/{ds}", img["id"]

    for method, url, kw in [
        ("get", f"/d/{ds}", {}), ("get", f"/d/{ds}/i/{iid}", {}), ("post", f"/d/{ds}/delete", {}),
        ("get", base, {}), ("put", f"{base}/classes", {"json": {"classes": ["a", "b"]}}),
        ("post", f"{base}/images", {"files": [("files", ("y.jpg", jpg(), "image/jpeg"))]}),
        ("post", f"{base}/import", {"files": [("file", ("d.zip", zip_bytes({"a.jpg": jpg()}), "application/zip"))]}),
        ("get", f"{base}/images/{iid}/file", {}), ("get", f"{base}/images/{iid}/preview", {}),
        ("get", f"{base}/images/{iid}/annotation", {}),
        ("put", f"{base}/images/{iid}/annotation", {"json": {"shapes": []}}),
        ("patch", f"{base}/images/{iid}", {"json": {"split": "val"}}),
        ("delete", f"{base}/images/{iid}", {}), ("get", f"{base}/export", {}),
    ]:
        r = getattr(bob, method)(url, follow_redirects=False, **kw)
        assert r.status_code == 404, (method, url, r.status_code)

    # картинка датасета другого датасета того же владельца тоже не доступна по чужому id
    other = create(alice, "detect", "a")
    assert alice.get(f"/api/datasets/{other}/images/{iid}/file").status_code == 404
    assert alice.get(f"{base}/images/{iid}/file").status_code == 200


def test_roboflow_obb_zip_roundtrip_opens_in_acmenra_ds(make_client, tmp_path):
    from acmenra_ds import Dataset

    c = make_client()
    ds = create(c, "obb")
    # Roboflow: выборки сверху, внутри images/labels, в yaml пути ../train/images, OBB — четыре угла
    cx, cy, w, h, a = 320, 240, 200, 80, math.radians(30)
    corners = []
    for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        lx, ly = dx * w / 2, dy * h / 2
        corners += [(cx + lx * math.cos(a) - ly * math.sin(a)) / W, (cy + lx * math.sin(a) + ly * math.cos(a)) / H]
    line = "1 " + " ".join(f"{v:.6f}" for v in corners) + "\n"
    archive = zip_bytes({
        "data.yaml": yaml.safe_dump({"train": "../train/images", "val": "../valid/images", "test": "../test/images",
                                     "nc": 2, "names": ["каска", "жилет"]}, allow_unicode=True),
        "train/images/кадр 1.jpg": jpg(), "train/labels/кадр 1.txt": line,
        "train/images/b.jpg": jpg(), "train/labels/b.txt": "7 0.5 0.5 0.1 0.1 0.2 0.2 0.3 0.3\n",
        "valid/images/c.jpg": jpg(), "valid/labels/c.txt": line,
        "test/images/d.jpg": jpg(),
        "__MACOSX/train/images/._b.jpg": b"junk",
    })
    r = c.post(f"/api/datasets/{ds}/import", files=[("file", ("ds.zip", archive, "application/zip"))]).json()
    assert r["added"] == 4 and r["skipped"] == 1 and "класс 7" in r["skipped_examples"][0]
    assert r["classes"] == ["каска", "жилет"]
    images = c.get(f"/api/datasets/{ds}").json()["images"]
    assert sorted(i["split"] for i in images) == ["test", "train", "train", "val"]
    assert any(i["name"] == "kadr_1.jpg" for i in images)

    for fmt in ("acmenra", "ultralytics"):
        out = tmp_path / fmt
        zipfile.ZipFile(io.BytesIO(c.get(f"/api/datasets/{ds}/export", params={"format": fmt}).content)).extractall(out)
        assert (out / "images/valid/c.jpg").exists() and (out / "images/test/d.jpg").exists()
        first = (out / "labels/train/kadr_1.txt").read_text().split()
        assert len(first) == (6 if fmt == "acmenra" else 9)

    category = Enum("Classes", {"KASKA": 0, "ZHILET": 1})
    dataset = Dataset.from_yaml(tmp_path / "acmenra" / "data.yaml", category=category, is_strict=True)
    report = dataset.health()
    assert report["is_healthy"], report["errors"]
    assert (len(dataset.train), len(dataset.val), len(dataset.test)) == (2, 1, 1)
    inst = [x for i in range(len(dataset.train)) for x in dataset.train.get_instances(i)]
    assert len(inst) == 1 and inst[0].class_id == 1
    got = inst[0].obb.to_xywhrn()
    assert got == pytest.approx((cx / W, cy / H, w / W, h / H, a), abs=1e-4)


def test_ultralytics_segment_zip_and_preview(make_client):
    c = make_client()
    ds = create(c, "segment", "фон")
    archive = zip_bytes({
        "set/data.yaml": "names:\n  0: человек\n  1: фон\n",
        "set/images/train/a.png": jpg(), "set/labels/train/a.txt": "0 0.1 0.1 0.5 0.1 0.3 0.6\n1 0.1 0.1 0.2 0.2\n",
        "set/images/val/b.png": jpg(),
    })
    r = c.post(f"/api/datasets/{ds}/import", files=[("file", ("ds.zip", archive, "application/zip"))]).json()
    # существующий класс «фон» сохранил номер 0, «человек» дописан номером 1
    assert r["classes"] == ["фон", "человек"] and r["skipped"] == 1
    img = next(i for i in c.get(f"/api/datasets/{ds}").json()["images"] if i["name"] == "a.png")
    ann = c.get(f"/api/datasets/{ds}/images/{img['id']}/annotation").json()
    assert [s["cls"] for s in ann["shapes"]] == [1]
    prev = c.get(f"/api/datasets/{ds}/images/{img['id']}/preview")
    assert prev.status_code == 200 and prev.content[:2] == b"\xff\xd8"

    bad = c.put(f"/api/datasets/{ds}/images/{img['id']}/annotation",
                json={"shapes": [{"type": "polygon", "cls": 5, "points": [[0, 0], [1, 1], [2, 0]]}]})
    assert bad.status_code == 400
    page = c.get(f"/d/{ds}?split=val")
    assert page.status_code == 200 and "b.png" in page.text and "a.png" not in page.text


def _deps(dependant):
    for d in dependant.dependencies:
        yield d.call
        yield from _deps(d)


def test_every_dataset_route_checks_owner_and_login(make_client):
    """Новый маршрут с {dataset_id} без проверки владельца должен уронить тест, а не уехать в прод."""
    from fastapi.routing import APIRoute

    from app import auth
    from app.api import router
    from app.main import app

    anon = make_client(None)
    # FastAPI 0.16x хранит подключённый роутер одним объектом, поэтому маршруты API берём из него
    routes = [r for r in [*app.routes, *router.routes] if isinstance(r, APIRoute) and "{dataset_id}" in r.path]
    assert len(routes) >= 16  # страницы, API и снятие с публикации в админке
    writers = {auth.own_dataset, auth.own_dataset_page, auth.admin_page}
    readers = writers | {auth.readable_dataset, auth.readable_dataset_page}
    for r in routes:
        deps = set(_deps(r.dependant))
        assert readers & deps, r.path
        # всё, что меняет данные, — только владельцу (или админу для снятия с публикации)
        # копирование и лайк читают чужой открытый датасет, а пишут только своё:
        # новый датасет копирующего или отметку «нравится» — сам датасет не меняют
        if r.methods - {"GET", "HEAD"} and r.path not in ("/d/{dataset_id}/copy", "/d/{dataset_id}/like"):
            owner_or_admin = {auth.own_dataset, auth.own_dataset_page} if not r.path.startswith("/admin") else {auth.admin_page}
            assert owner_or_admin & deps and not ({auth.readable_dataset, auth.readable_dataset_page} & deps), r.path
        url = r.path.replace("{dataset_id}", "abcd1234").replace("{image_id}", "1")
        for method in r.methods:
            resp = anon.request(method, url, follow_redirects=False)
            assert resp.status_code in (401, 303, 422), (method, url, resp.status_code)

    # и каждый адрес админки закрыт admin_page — даже без {dataset_id}
    admin_routes = [r for r in app.routes if isinstance(r, APIRoute) and r.path.startswith("/admin")]
    assert len(admin_routes) == 4
    for r in admin_routes:
        assert auth.admin_page in set(_deps(r.dependant)), r.path


def test_hostile_zip_lines_are_skipped_not_fatal(make_client):
    c = make_client()
    ds = create(c, "detect")
    archive = zip_bytes({
        "images/a.jpg": jpg(),
        "labels/a.txt": "999999999 0.5 0.5 0.1 0.1\n1e300 0.5 0.5 0.1 0.1\ninf 0.5 0.5 0.1 0.1\n"
                        "0 inf 0.5 0.1 0.1\n-1 0.5 0.5 0.1 0.1\n2 0.5 0.5 0.1 0.1\n",
    })
    r = c.post(f"/api/datasets/{ds}/import", files=[("file", ("ds.zip", archive, "application/zip"))])
    assert r.status_code == 200
    body = r.json()
    assert body["added"] == 1 and body["skipped"] == 5
    assert body["classes"] == ["class_0", "class_1", "class_2"]


def test_huge_image_and_login_bruteforce_are_refused(make_client):
    c = make_client()
    ds = create(c, "detect", "a")
    buf = io.BytesIO()
    PILImage.new("1", (7000, 7000)).save(buf, "PNG")  # ~49 Мп, а файл — килобайты
    r = c.post(f"/api/datasets/{ds}/images", files=[("files", ("big.png", buf.getvalue(), "image/png"))]).json()
    assert r["added"] == [] and "Мп" in r["errors"][0]

    other = make_client(None)
    for _ in range(10):
        assert other.post("/login", data={"email": "a@example.com", "password": "wrong-password"}).status_code == 400
    blocked = other.post("/login", data={"email": "a@example.com", "password": "correct-horse"})
    assert blocked.status_code == 429


def test_published_dataset_is_readonly_for_others(make_client):
    alice, bob = make_client("alice@example.com"), make_client("bob@example.com")
    ds = create(alice, "detect", "a")
    iid = alice.post(f"/api/datasets/{ds}/images", files=[("files", ("x.jpg", jpg(), "image/jpeg"))]).json()["added"][0]["id"]
    base = f"/api/datasets/{ds}"
    assert bob.get(f"/d/{ds}").status_code == 404
    assert "alice" not in bob.get("/catalog").text

    assert alice.post(f"/d/{ds}/publish", data={"public": "1"}, follow_redirects=False).status_code == 303
    cat = bob.get("/catalog").text
    assert "a***@example.com" in cat and "alice@example.com" not in cat
    page = bob.get(f"/d/{ds}")
    assert page.status_code == 200 and "Только просмотр" in page.text and "Удалить датасет" not in page.text
    assert bob.get(base).json()["readonly"] is True and alice.get(base).json()["readonly"] is False
    for url in (f"/d/{ds}/i/{iid}", f"{base}/images/{iid}/file", f"{base}/images/{iid}/preview",
                f"{base}/images/{iid}/annotation", f"{base}/export"):
        assert bob.get(url).status_code == 200, url

    for method, url, kw in [
        ("put", f"{base}/images/{iid}/annotation", {"json": {"shapes": []}}),
        ("patch", f"{base}/images/{iid}", {"json": {"split": "val"}}),
        ("delete", f"{base}/images/{iid}", {}), ("put", f"{base}/classes", {"json": {"classes": ["a", "b"]}}),
        ("post", f"{base}/images", {"files": [("files", ("y.jpg", jpg(), "image/jpeg"))]}),
        ("post", f"/d/{ds}/publish", {"data": {"public": "0"}}), ("post", f"/d/{ds}/delete", {}),
    ]:
        assert getattr(bob, method)(url, follow_redirects=False, **kw).status_code == 404, (method, url)

    alice.post(f"/d/{ds}/publish", data={"public": "0"})
    assert bob.get(f"/d/{ds}").status_code == 404 and bob.get(f"{base}/export").status_code == 404


def test_admin_panel(make_client):
    from app import db
    admin, bob, carol = make_client("admin@example.com"), make_client("bob@example.com"), make_client("carol@example.com")
    assert bob.get("/admin").status_code == 404
    with next(db.get_db()) as s:
        s.query(db.User).filter(db.User.email == "admin@example.com").update({"is_admin": True})
        s.commit()
    page = admin.get("/admin")
    assert page.status_code == 200 and "bob@example.com" in page.text
    ids = {u.email: u.id for u in next(db.get_db()).query(db.User)}

    # обычный пользователь не может ни блокировать, ни удалять
    assert bob.post(f"/admin/users/{ids['carol@example.com']}/block", data={"blocked": "1"},
                    follow_redirects=False).status_code == 404
    assert bob.post(f"/admin/users/{ids['carol@example.com']}/delete", follow_redirects=False).status_code == 404
    assert admin.post(f"/admin/users/{ids['admin@example.com']}/block", data={"blocked": "1"}).status_code == 400

    private = create(carol, "detect", "a")
    assert admin.get(f"/d/{private}").status_code == 404  # закрытые датасеты админ не читает

    shared = create(bob, "detect", "a")
    bob.post(f"/d/{shared}/publish", data={"public": "1"})
    admin.post(f"/admin/users/{ids['bob@example.com']}/block", data={"blocked": "1"})
    assert bob.get("/", follow_redirects=False).headers["location"].startswith("/login")  # сеанс завершён сразу
    assert carol.get(f"/d/{shared}").status_code == 404  # датасеты заблокированного пропали из каталога
    blocked = bob.post("/login", data={"email": "bob@example.com", "password": "correct-horse"})
    assert blocked.status_code == 403 and "заблокирован" in blocked.text
    admin.post(f"/admin/users/{ids['bob@example.com']}/block", data={"blocked": "0"})
    assert bob.post("/login", data={"email": "bob@example.com", "password": "correct-horse"},
                    follow_redirects=False).status_code == 303

    carol.post(f"/d/{private}/publish", data={"public": "1"})
    admin.post(f"/admin/datasets/{private}/unpublish")
    assert bob.get(f"/d/{private}").status_code == 404

    from app import datasets
    folder = datasets.dataset_dir(private)
    carol.post(f"/api/datasets/{private}/images", files=[("files", ("x.jpg", jpg(), "image/jpeg"))])
    assert folder.exists()
    admin.post(f"/admin/users/{ids['carol@example.com']}/delete")
    assert not folder.exists() and "carol@example.com" not in admin.get("/admin").text


def test_old_database_gets_new_columns(tmp_path, monkeypatch):
    import sqlite3

    from sqlalchemy import inspect

    from app import db
    data = tmp_path / "data"
    data.mkdir()
    con = sqlite3.connect(data / "acmenra.db")
    con.executescript("""
        CREATE TABLE users (id INTEGER PRIMARY KEY, email VARCHAR(254), password_hash VARCHAR(200), created_at DATETIME);
        CREATE TABLE datasets (id VARCHAR(8) PRIMARY KEY, owner_id INTEGER, name VARCHAR(200), task VARCHAR(16),
                               classes JSON, created_at DATETIME);
        INSERT INTO users VALUES (1, 'old@example.com', 'x', '2026-11-05 10:00:00');
    """)
    con.commit()
    con.close()
    monkeypatch.setenv("ACMENRA_DATA_DIR", str(data))
    db.reset()
    cols = {c["name"] for c in inspect(db.engine()).get_columns("users")}
    assert {"is_admin", "is_blocked", "last_login_at"} <= cols
    with next(db.get_db()) as s:
        assert s.get(db.User, 1).is_blocked is False
    db.reset()


def png_bytes(size=(400, 300)) -> bytes:
    buf = io.BytesIO()
    PILImage.new("RGB", size, (200, 80, 40)).save(buf, "PNG")
    return buf.getvalue()


def test_profile_name_and_avatar(make_client):
    alice, bob = make_client("alice@example.com"), make_client("bob@example.com")
    assert alice.post("/profile", data={"display_name": "  Алиса   <b>Смирнова</b> "}, follow_redirects=False).status_code == 303
    ds = create(alice, "detect", "a")
    alice.post(f"/d/{ds}/publish", data={"public": "1"})
    cat = bob.get("/catalog").text
    assert "Алиса &lt;b&gt;Смирнова&lt;/b&gt;" in cat and "a***@example.com" not in cat  # имя вместо email, HTML экранирован
    assert alice.post("/profile", data={"display_name": "я" * 61}).status_code == 400

    bad = alice.post("/profile/avatar", files=[("file", ("x.png", b"not an image", "image/png"))])
    assert bad.status_code == 400 and "не картинка" in bad.text
    assert alice.post("/profile/avatar", files=[("file", ("me.png", png_bytes(), "image/png"))],
                      follow_redirects=False).status_code == 303
    from app import db
    uid = next(db.get_db()).query(db.User).filter(db.User.email == "alice@example.com").one().id
    av = bob.get(f"/avatars/{uid}.png")
    assert av.status_code == 200 and PILImage.open(io.BytesIO(av.content)).size == (256, 256)
    assert make_client(None).get(f"/avatars/{uid}.png", follow_redirects=False).status_code == 303  # без входа нельзя
    alice.post("/profile/avatar/delete")
    assert bob.get(f"/avatars/{uid}.png").status_code == 404


def test_settings_password_email_sessions_delete(make_client):
    from app import db
    alice = make_client("alice@example.com")
    laptop = make_client(None)
    laptop.post("/login", data={"email": "alice@example.com", "password": "correct-horse"})
    assert laptop.get("/", follow_redirects=False).status_code == 200

    wrong = alice.post("/settings/password", data={"current": "nope-nope", "new": "brand-new-pass"})
    assert wrong.status_code == 400 and "неверный" in wrong.text
    assert alice.post("/settings/password", data={"current": "correct-horse", "new": "brand-new-pass"},
                      follow_redirects=False).status_code == 303
    assert alice.get("/", follow_redirects=False).status_code == 200          # текущий сеанс жив
    assert laptop.get("/", follow_redirects=False).status_code == 303         # другой — вышел
    assert laptop.post("/login", data={"email": "alice@example.com", "password": "brand-new-pass"},
                       follow_redirects=False).status_code == 303

    make_client("taken@example.com")
    assert alice.post("/settings/email", data={"email": "TAKEN@example.com", "password": "brand-new-pass"}).status_code == 400
    assert alice.post("/settings/email", data={"email": "alice2@example.com", "password": "brand-new-pass"},
                      follow_redirects=False).status_code == 303

    assert alice.post("/settings/sessions", follow_redirects=False).status_code == 303
    assert laptop.get("/", follow_redirects=False).status_code == 303

    assert alice.post("/settings/theme", data={"theme": "dark"}, follow_redirects=False).status_code == 303
    assert 'data-theme="dark"' in alice.get("/").text
    assert alice.post("/settings/theme", data={"theme": "<script>"}).status_code == 400

    ds = create(alice, "detect", "a")
    from app import datasets
    folder = datasets.dataset_dir(ds)
    assert alice.post("/settings/delete", data={"password": "wrong-pass"}).status_code == 400
    assert alice.post("/settings/delete", data={"password": "brand-new-pass"}, follow_redirects=False).status_code == 303
    assert not folder.exists()
    assert next(db.get_db()).query(db.User).filter(db.User.email == "alice2@example.com").count() == 0


def test_copy_public_dataset_to_own(make_client):
    from app import datasets, db
    alice, bob = make_client("alice@example.com"), make_client("bob@example.com")
    src = create(alice, "detect", "ящик,шар")
    iid = alice.post(f"/api/datasets/{src}/images", files=[("files", ("x.jpg", jpg(), "image/jpeg"))],
                     data={"split": "val"}).json()["added"][0]["id"]
    alice.put(f"/api/datasets/{src}/images/{iid}/annotation",
              json={"shapes": [{"type": "box", "cls": 1, "x": 10, "y": 10, "w": 50, "h": 40}]})

    assert bob.post(f"/d/{src}/copy", follow_redirects=False).status_code == 404   # закрытый не копируется
    alice.post(f"/d/{src}/publish", data={"public": "1"})
    r = bob.post(f"/d/{src}/copy", follow_redirects=False)
    assert r.status_code == 303
    copy = r.headers["location"].split("/d/")[1].split("?")[0]
    assert copy != src

    data = bob.get(f"/api/datasets/{copy}").json()
    assert data["readonly"] is False and data["classes"] == ["ящик", "шар"]
    assert data["images"][0]["split"] == "val" and data["images"][0]["count"] == 1
    page = bob.get(f"/d/{copy}").text
    assert "(копия)" in page and "badge public" not in page                  # копия закрыта
    assert alice.get(f"/d/{copy}").status_code == 404                        # автор оригинала копию не видит

    # копия независима: правка в ней не трогает оригинал
    new_iid = data["images"][0]["id"]
    bob.put(f"/api/datasets/{copy}/images/{new_iid}/annotation", json={"shapes": []})
    assert len(alice.get(f"/api/datasets/{src}/images/{iid}/annotation").json()["shapes"]) == 1
    assert bob.get(f"/api/datasets/{copy}/images/{new_iid}/file").content == alice.get(f"/api/datasets/{src}/images/{iid}/file").content
    with next(db.get_db()) as s:
        assert s.get(db.Dataset, copy).forked_from == src
    assert datasets.dataset_dir(copy) != datasets.dataset_dir(src)


def _uid(email):
    from app import db
    with next(db.get_db()) as s:
        return s.query(db.User).filter(db.User.email == email).one().id


def _board(client, period="all"):
    """{email: баллы} из страницы рейтинга, через публичные профили не ходим — читаем модуль."""
    from app import community, db
    with next(db.get_db()) as s:
        return {sc.user.email: sc for sc in community.scores(s, period)}


def _annotated(client, ds, n_objects):
    iid = client.post(f"/api/datasets/{ds}/images", files=[("files", ("x.jpg", jpg(), "image/jpeg"))]).json()["added"][0]["id"]
    shapes = [{"type": "box", "cls": 0, "x": 1 + i, "y": 1, "w": 5, "h": 5} for i in range(n_objects)]
    assert client.put(f"/api/datasets/{ds}/images/{iid}/annotation", json={"shapes": shapes}).status_code == 200


def test_leaderboard_rules(make_client):
    alice, bob, carol = make_client("alice@example.com"), make_client("bob@example.com"), make_client("carol@example.com")
    ds = create(alice, "detect", "a")
    _annotated(alice, ds, 35)                       # 35 объектов → 3 балла объёма

    # закрытый: лайкнуть нельзя, баллов нет
    assert bob.post(f"/d/{ds}/like", follow_redirects=False).status_code == 404
    assert _board(alice) == {}

    alice.post(f"/d/{ds}/publish", data={"public": "1"})
    assert _board(alice)["alice@example.com"].total == 3

    # своё не считается: лайк, скачивание, копия, просмотр
    assert alice.post(f"/d/{ds}/like", follow_redirects=False).status_code == 400
    alice.get(f"/api/datasets/{ds}/export")
    alice.post(f"/d/{ds}/copy")
    alice.get(f"/d/{ds}")
    assert _board(alice)["alice@example.com"].total == 3

    # чужие: лайк 5, копия + скачивание от одного человека — одно переиспользование, 10
    bob.get(f"/d/{ds}")
    bob.get(f"/d/{ds}")                              # второй просмотр за сутки не считается
    assert bob.post(f"/d/{ds}/like", follow_redirects=False).status_code == 303
    bob.get(f"/api/datasets/{ds}/export")
    bob.get(f"/api/datasets/{ds}/export")
    r = bob.post(f"/d/{ds}/copy", follow_redirects=False)
    bob_copy = r.headers["location"].split("/d/")[1].split("?")[0]
    carol.get(f"/api/datasets/{ds}/export")
    a = _board(alice)["alice@example.com"]
    assert (a.likes, a.reuses, a.volume, a.total) == (1, 2, 3, 3 + 5 + 2 * 10)

    page = carol.get("/catalog?sort=popular").text
    assert "тест" in page
    from app import community, db
    with next(db.get_db()) as s:
        st = community.dataset_stats(s, [ds])[ds]
    assert st == {"views": 1, "likes": 1, "reuses": 2}

    # копия не даёт объёма, даже опубликованная
    bob.post(f"/d/{bob_copy}/publish", data={"public": "1"})
    assert "bob@example.com" not in _board(alice)

    # лайк снимается повторным нажатием
    bob.post(f"/d/{ds}/like")
    assert _board(alice)["alice@example.com"].likes == 0

    # потолок объёма: 2000 объектов → 100, не 200
    big = create(carol, "detect", "a")
    _annotated(carol, big, 2000)
    carol.post(f"/d/{big}/publish", data={"public": "1"})
    assert _board(alice)["carol@example.com"].volume == 100

    # снял с публикации — баллы за датасет пропали
    alice.post(f"/d/{ds}/publish", data={"public": "0"})
    assert "alice@example.com" not in _board(alice)

    # страницы открываются, своя строка подсвечена, у заблокированного профиля нет
    assert "Рейтинг" in carol.get("/leaderboard?period=all").text
    assert carol.get(f"/u/{_uid('carol@example.com')}").status_code == 200
    assert "carol@example.com" not in alice.get(f"/u/{_uid('carol@example.com')}").text   # чужим email не виден


def test_week_counts_only_recent(make_client):
    from datetime import timedelta

    from app import db
    alice, bob = make_client("alice@example.com"), make_client("bob@example.com")
    ds = create(alice, "detect", "a")
    alice.post(f"/d/{ds}/publish", data={"public": "1"})
    bob.post(f"/d/{ds}/like")
    with next(db.get_db()) as s:
        like = s.query(db.Like).one()
        like.created_at = db.now() - timedelta(days=10)
        s.get(db.Dataset, ds).published_at = db.now() - timedelta(days=10)
        s.commit()
    assert _board(alice, "all")["alice@example.com"].likes == 1
    assert "alice@example.com" not in _board(alice, "week")
